"""Renders index.html (the home page) from the data build.py collects.
Highlights (one card per match, multi-language), matchday strips, story-clustered news, articles,
plus the trivia card, tactical guide chips, thrill badges and the matchday reel."""
import datetime
import html
import json
import re

import enhance as E

e = html.escape
UTC = datetime.timezone.utc
LANG_LABEL = {"en": "EN", "ar": "عربي", "it": "IT", "es": "ES", "fr": "FR", "de": "DE", "pt": "PT"}
LANG_BTN = {"en": "🇬🇧 English", "ar": "🇲🇦 العربية", "it": "🇮🇹 Italiano", "es": "🇪🇸 Español", "fr": "🇫🇷 Français", "de": "🇩🇪 Deutsch", "pt": "🇵🇹 Português"}


def ts(d):
    return int(d.timestamp())


def ago_span(d):
    sec = (datetime.datetime.now(UTC) - d).total_seconds()
    txt = f"{max(1, int(sec // 60))} min ago" if sec < 3600 else f"{int(sec // 3600)} h ago" if sec < 86400 else f"{int(sec // 86400)} d ago"
    return f'<span class="ago" data-t="{ts(d)}">{txt}</span>'


def crest_img(logo, name):
    if logo:
        return f'<img src="{e(logo)}" alt="" loading="lazy" width="44" height="44">'
    ini = "".join(w[0] for w in re.sub(r"[^A-Za-z0-9 ]", "", name).split()[:2]).upper() or "⚽"
    return f'<span class="ini">{e(ini)}</span>'


def video_card(c, B):
    lg = B.league_of_video(c)
    names = {k: league for k, _c, _country, league, _kw in B.LEAGUES}
    f = c.get("fixture")
    vers = c["versions"]
    langs = " ".join(v["lang"] for v in vers)
    thr = f.get("thrill") if f else None
    lab = E.thrill_label(thr)
    badge = (f'<span class="thr {lab}">{"🔥" if lab == "classic" else "⚡"} {thr}% <i data-i18n="thr_{lab}">'
             f'{"Instant Classic" if lab == "classic" else "Great Watch"}</i></span>') if lab else ""
    ext = '<span class="ext" data-i18n="yt_off">↗ Official YouTube</span>'
    cover = ""
    if f:
        cover = (f'<div class="sfcover">{crest_img(f.get("hlogo", ""), f["home"])}<b>{e(f["home"])}</b><i>vs</i>'
                 f'<b>{e(f["away"])}</b>{crest_img(f.get("alogo", ""), f["away"])}</div>')
    else:
        cover = f'<div class="sfcover"><b>{e(names.get(lg, ""))}</b></div>'
    if len(vers) > 1:
        aud = '<span class="aud">🎙️ ' + "".join(
            f'<b class="ab{" on" if i == 0 else ""}" data-v="{e(v["id"])}" data-lg="{v["lang"]}" data-o="{e(B.nice_title(v["title"]))}">{LANG_LABEL.get(v["lang"], v["lang"].upper())}</b>'
            for i, v in enumerate(vers)) + "</span>"
    else:
        aud = f'<span class="cmtag">🎙️ {LANG_LABEL.get(vers[0]["lang"], "EN")}</span>'
    g = E.guide_of(c["title"])
    chip = f'<span class="tac" data-g="{g[0]}">💡 <i data-i18n="guide">60-sec guide</i>: {e(g[1])}</span>' if g else ""
    s = " ".join(B.plain(v["title"]) for v in vers)
    if f:
        s += " " + B.plain(f["home"] + " " + f["away"])
    noemb = "" if all(v.get("embed", True) for v in vers) else ' data-ext="1"'
    return (f'<a class="vid card" data-l="{lg}" data-c="{langs}" data-s="{e(s)}" data-ts="{ts(c["date"])}" data-thrill="{thr or 0}"'
            f' data-ch="{e(c["channel"])}"{noemb} href="https://www.youtube.com/watch?v={e(c["id"])}" target="_blank" rel="noopener">'
            f'<div class="thumb"><img src="https://i.ytimg.com/vi/{e(c["id"])}/hqdefault.jpg" alt="" loading="lazy" width="480" height="360">'
            f'<span class="play">▶</span>{badge}{ext}{cover}</div>'
            f'<div class="vt" data-n="{e(c.get("neutral", ""))}">{e(B.nice_title(c["title"]))}</div>'
            f'<div class="meta">{B.flag(lg)} <span data-i18n="lg_{lg}">{e(names.get(lg, ""))}</span> · {ago_span(c["date"])} · {aud}</div>{chip}</a>')


def news_card(n, B):
    lg = B.league_of_news(n)
    srcs = ""
    if n.get("also"):
        srcs = ('<div class="srcs"><span data-i18n="also">Also on:</span> ' + "".join(
            f'<span class="src" data-u="{e(a["link"])}" title="{e(a["title"])}">{e(a["source"])}</span>' for a in n["also"][:4]) + "</div>")
    g = E.guide_of(n["title"] + " " + n.get("summary", ""))
    chip = f'<span class="tac" data-g="{g[0]}">💡 <i data-i18n="guide">60-sec guide</i>: {e(g[1])}</span>' if g else ""
    text = " ".join([n["title"], n["summary"]] + [a["title"] for a in n.get("also", [])])
    return (f'<a class="news card" data-l="{lg}" data-s="{e(B.plain(text))}" href="{e(n["link"])}" target="_blank" rel="noopener">'
            + (f'<img class="nimg" src="{e(n["image"])}" alt="" loading="lazy" width="480" height="270">' if n.get("image") else "")
            + f'<div><div class="nt">{e(n["title"])} <span class="enb">EN</span></div><p>{e(n["summary"])}</p>'
              f'<div class="meta">{B.flag(lg)} {e(n["source"])} · {ago_span(n["date"])}</div>{srcs}{chip}</div></a>')


def match_rows(fx, cards, slugs, B):
    """Compact one-line rows grouped by competition (FotMob/Flashscore style)."""
    import matchpages
    now = datetime.datetime.now(UTC)
    vid_of = {c["fixture"]["id"]: c for c in cards if c.get("fixture")}
    groups, order = {}, []
    for f in sorted(fx, key=lambda x: x["date"]):
        d = B.parse_date(f["date"])
        if d is None or d < now - datetime.timedelta(days=2):
            continue
        st = f.get("state") or ("in" if f.get("live") else "pre")
        if f["comp"] not in groups:
            groups[f["comp"]] = []
            order.append((f["comp"], f["l"]))
        if st == "pre":
            mid = '<span class="vs">vs</span>'
        else:
            mid = f'<b class="sc spoil">{e(str(f.get("hs", "")))}–{e(str(f.get("as", "")))}</b>'
        when = (f'<span class="lvb">● <span data-i18n="live">LIVE</span> {e(f.get("clock", ""))}</span>' if st == "in"
                else f'<span class="mt2 ft" data-i18n="ft">FT</span>' if st == "post" else f'<span class="mt2" data-k="{ts(d)}">{d.strftime("%H:%M")}</span>')
        acts = ""
        if st == "post" and f["id"] in vid_of:
            acts += f'<button class="hlb" data-v="{e(vid_of[f["id"]]["id"])}">▶ <span data-i18n="hl_btn">Highlights</span></button>'
        thr = f.get("thrill")
        lab = E.thrill_label(thr)
        if st == "post" and lab:
            acts += f'<span class="thr {lab}">{"🔥" if lab == "classic" else "⚡"} {thr}%</span>'
        if st != "post" and f.get("id"):
            acts += f'<a class="trk" href="live.html#{e(f["code"])}/{e(f["id"])}" title="Live tracker">🔴</a>'
        if f.get("id") in (slugs or {}):
            acts += f'<a class="go" href="matches/{e(slugs[f["id"]])}.html" aria-label="Match page">›</a>'
        groups[f["comp"]].append(
            f'<div class="mrw" data-l="{f["l"]}" data-s="{e(B.plain(f["home"] + " " + f["away"]))}" data-k="{ts(d)}" data-st="{st}">'
            f'{when}<span class="mtm h" data-team="{e(f["home"])}"><span class="tn">{e(f["home"])}</span>{crest_img(f.get("hlogo", ""), f["home"])}</span>'
            f'<span class="mmid">{mid}</span>'
            f'<span class="mtm a" data-team="{e(f["away"])}">{crest_img(f.get("alogo", ""), f["away"])}<span class="tn">{e(f["away"])}</span></span>'
            f'<span class="mtv">{matchpages.tv_spans(f)}</span><span class="mact">{acts}</span></div>')
    out = []
    for comp, lg in order:
        out.append(f'<div class="mgrp" data-l="{lg}"><div class="mgh">{B.flag(lg)} {e(comp)}</div>{"".join(groups[comp])}</div>')
    return "".join(out)


def guides_json():
    from articles_src import ARTICLES
    out = {}
    for a in ARTICLES:
        if a["slug"] in {g[0] for g in E.GUIDES}:
            txt = re.sub(r"<[^>]+>", " ", a["body"])
            txt = re.sub(r"\s+", " ", html.unescape(txt)).strip()
            cut = txt[:520].rsplit(". ", 1)[0] + "."
            out[a["slug"]] = {"t": a["title"], "x": cut, "u": f"articles/{a['slug']}.html"}
    return out


def trivia_json():
    try:
        from quiz_src import QUIZ
    except Exception:
        return []
    return [{"i": i, "l": q["l"], "q": q["q"], "o": q["o"], "f": q["fact"]} for i, q in enumerate(QUIZ)]


def render(B, news_cards, cards, fx, teams, slugs):
    now = datetime.datetime.now(UTC).strftime("%d %b %Y, %H:%M UTC")
    vcards = "\n".join(video_card(c, B) for c in cards) or '<p class="empty">Highlights are loading – check back soon.</p>'
    ncards = "\n".join(news_card(n, B) for n in news_cards) or '<p class="empty">News is loading – check back soon.</p>'
    langs = []
    for c in cards:
        for v in c["versions"]:
            if v["lang"] not in langs:
                langs.append(v["lang"])
    langs.sort(key=lambda l: E.LANG_ORDER.index(l) if l in E.LANG_ORDER else 99)
    cm = '<button class="cmb on" data-c="all" data-i18n="all">All</button>' + "".join(
        f'<button class="cmb" data-c="{l}">{LANG_BTN.get(l, l)}</button>' for l in langs)
    chips = ('<button class="chip on" data-f="all">⚽ <span data-i18n="all">All</span></button>'
             '<button class="chip mychip" data-f="my">⭐ <span data-i18n="my_teams">My Teams</span></button>') + "".join(
        f'<button class="chip" data-f="{k}">{B.flag(k)} <span data-i18n="c_{k}">{e(country)}</span><small data-i18n="lg_{k}">{e(league)}</small></button>'
        for k, _c, country, league, _kw in B.LEAGUES)
    try:
        from articles_src import ARTICLES
        arts = sorted(ARTICLES, key=lambda a: a["date"], reverse=True)[:3]
    except Exception:
        arts = []
    acards = "\n".join(
        f'<a class="news card" href="articles/{e(a["slug"])}.html"><div><div class="nt">{e(a["title"])} <span class="enb">EN</span></div>'
        f'<p>{e(a["summary"])}</p><div class="meta">📝 {e(a["tag"])} · Football Arena</div></div></a>' for a in arts)
    rows = match_rows(fx, cards, slugs, B)
    data = {"guides": guides_json(), "quiz": trivia_json()}
    js = lambda o: json.dumps(o, ensure_ascii=False).replace("</", "<\\/")
    return (TEMPLATE.replace("{{MATCHES}}", rows or '<p class="empty" data-i18n="no_fix">No matches scheduled in the next few days.</p>')
            .replace("{{CHIPS}}", chips).replace("{{CM}}", cm).replace("{{ARTICLES}}", acards).replace("{{VIDEOS}}", vcards)
            .replace("{{NEWS}}", ncards).replace("{{UPDATED}}", now).replace("{{GSV}}", B.gsv_tags())
            .replace("{{TEAMS}}", js(list(teams))).replace("{{DATA}}", js(data)))


TEMPLATE = """<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Football Arena – Football Highlights & News by League</title>
<meta name="description" content="Latest football highlights and news sorted by country and league: Premier League, LaLiga, Serie A, Bundesliga, Ligue 1, Champions League and the World Cup. Spoiler-free mode, match TV channels and quizzes. Updated every hour.">
<meta property="og:title" content="Football Arena – Highlights, News & Quizzes">
<meta property="og:description" content="The latest football highlights and news by league, updated every hour. Test yourself with our football quiz.">
<meta property="og:image" content="https://www.footballarena.net/logo.png">
<link rel="canonical" href="https://www.footballarena.net/">
<meta property="og:url" content="https://www.footballarena.net/"><meta property="og:type" content="website"><meta property="og:site_name" content="Football Arena">
{{GSV}}
<script type="application/ld+json">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://www.footballarena.net/#website","name":"Football Arena","alternateName":"FootballArena.net","url":"https://www.footballarena.net/","inLanguage":["en","ar","fr","es","pt","de","it"]},{"@type":"Organization","@id":"https://www.footballarena.net/#org","name":"Football Arena","url":"https://www.footballarena.net/","logo":"https://www.footballarena.net/logo.png","sameAs":["https://www.facebook.com/1429286323597310"]}]}</script>
<link rel="icon" href="logo.png">
<link rel="preconnect" href="https://i.ytimg.com">
<style>
:root{--bg:#07140c;--card:#10251a;--line:#1f3d2b;--txt:#eef6f0;--mut:#9cb8a6;--acc:#2ee06f;--gold:#ffc83d}
*{box-sizing:border-box}html{scroll-behavior:smooth;scroll-padding-top:120px}
body{margin:0;background:var(--bg);color:var(--txt);font:16px/1.5 system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
a{color:inherit;text-decoration:none}button{font-family:inherit}
header{background:linear-gradient(135deg,#0b3d1f,#07140c 70%);padding:18px 16px 14px}
.wrap{max-width:1150px;margin:0 auto}
.brand{display:flex;align-items:center;gap:12px;flex-wrap:wrap}.brand img{width:52px;height:52px;border-radius:12px}
h1{margin:0;font-size:28px;letter-spacing:.5px}h1 span{color:var(--acc)}
.tag{color:var(--mut);margin:2px 0 0;font-size:14px}
.bar{position:sticky;top:0;z-index:5;background:rgba(7,20,12,.95);backdrop-filter:blur(6px);border-bottom:1px solid var(--line)}
nav{display:flex;gap:8px;overflow-x:auto;padding:10px 16px 2px;scrollbar-width:none}
nav a{white-space:nowrap;flex:none;padding:7px 16px;border-radius:22px;background:var(--card);border:1px solid var(--line);color:var(--txt);font-weight:600;font-size:15px;text-decoration:none;transition:background .15s,border-color .15s}nav a:hover{border-color:var(--acc);color:var(--txt)}nav a.on{background:var(--acc);border-color:var(--acc);color:#07140c}
.chips{display:flex;gap:8px;overflow-x:auto;padding:8px 16px 10px;scrollbar-width:none}
.chip{flex:none;display:flex;align-items:center;gap:6px;background:var(--card);color:var(--txt);border:1px solid var(--line);border-radius:22px;padding:6px 12px;font:600 14px system-ui,sans-serif;cursor:pointer}
.chip small{color:var(--mut);font-weight:500;font-size:12px}.chip.on{background:var(--acc);color:#04210f;border-color:var(--acc)}.chip.on small{color:#0b3d1f}
.chip.mychip{border-color:var(--gold)}.chip.mychip.on{background:var(--gold);border-color:var(--gold);color:#2a1d00}
.flag{width:20px;height:14px;border-radius:2px;object-fit:cover;vertical-align:-2px}.globe{width:auto;height:auto;font-size:14px}
main{padding:22px 16px 40px}
h2{font-size:21px;margin:4px 0 14px;display:flex;align-items:center;gap:8px;flex-wrap:wrap}
h2:before{content:"";width:6px;height:22px;background:var(--acc);border-radius:3px}
h2 .count{color:var(--mut);font-size:14px;font-weight:500}
.shead{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap}.shead h2{margin-bottom:10px}
.grid{display:grid;gap:14px;grid-template-columns:repeat(auto-fill,minmax(260px,1fr))}
.card{background:var(--card);border:1px solid var(--line);border-radius:14px;overflow:hidden;transition:transform .15s,border-color .15s}
.card:hover{transform:translateY(-2px);border-color:var(--acc)}.card.hide{display:none}
.thumb{position:relative;aspect-ratio:16/9;background:#000;display:grid;place-items:center;overflow:hidden}
.thumb>img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;transition:filter .25s}
.play{position:relative;width:50px;height:50px;border-radius:50%;background:rgba(0,0,0,.6);display:grid;place-items:center;font-size:20px;color:#fff}
.thr{position:absolute;top:8px;inset-inline-start:8px;z-index:3;font:800 12px system-ui,sans-serif;border-radius:12px;padding:4px 9px;white-space:nowrap}
.thr i{font-style:normal;font-weight:700}.thr.classic{background:linear-gradient(90deg,var(--gold),var(--acc));color:#04210f;box-shadow:0 0 14px rgba(255,200,61,.55)}
.thr.great{background:rgba(42,42,12,.92);color:var(--gold);border:1px solid var(--gold)}
.mact .thr{position:static;font-size:11px;padding:2px 7px}
.ext{display:none;position:absolute;bottom:8px;inset-inline-end:8px;z-index:3;background:rgba(0,0,0,.75);color:#fff;font:700 11px system-ui;border-radius:8px;padding:3px 8px}
.card[data-ext] .ext{display:block}
.vt,.nt{font-weight:700;padding:10px 12px 2px;line-height:1.3}.meta{color:var(--mut);font-size:13px;padding:2px 12px 12px}
.aud{display:inline-flex;gap:3px;align-items:center;white-space:nowrap}.ab{font:700 11px system-ui;border:1px solid var(--line);border-radius:6px;padding:1px 6px;cursor:pointer;color:var(--txt)}
.ab.on{background:var(--gold);border-color:var(--gold);color:#2a1d00}.cmtag{white-space:nowrap}
.tac{display:inline-block;margin:0 12px 12px;font:700 12px system-ui;color:var(--gold);background:#2a2a0c;border:1px solid #4b5a1f;border-radius:14px;padding:3px 10px;cursor:pointer}
.tac i{font-style:normal}.tac:hover{border-color:var(--gold)}
.news{display:flex;flex-direction:column}.nimg{width:100%;height:auto;aspect-ratio:16/9;object-fit:cover;background:#000}
.news p{color:var(--mut);font-size:14px;margin:4px 12px 4px}
.srcs{display:flex;flex-wrap:wrap;gap:5px;align-items:center;padding:0 12px 12px;font-size:12px;color:var(--mut)}
.src{border:1px solid var(--line);border-radius:12px;padding:2px 9px;color:var(--txt);font-weight:600;cursor:pointer}.src:hover{border-color:var(--acc)}
.more{display:block;margin:16px auto 0;background:none;border:1px solid var(--acc);color:var(--acc);border-radius:22px;padding:9px 22px;font:600 15px system-ui,sans-serif;cursor:pointer}
.more:hover{background:var(--acc);color:#04210f}
section{margin-bottom:38px}.empty{color:var(--mut)}
.tools{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:-4px 0 14px;color:var(--mut);font-size:14px;font-weight:600}
@media(max-width:620px){.tools{flex-wrap:nowrap;overflow-x:auto;scrollbar-width:none;margin-inline:-16px;padding-inline:16px}.tools>*{flex:none}.reelb{margin-inline-start:0}}
.cmb,.srt{background:var(--card);color:var(--txt);border:1px solid var(--line);border-radius:20px;padding:5px 12px;font:600 14px system-ui,sans-serif;cursor:pointer}
.cmb.on,.srt.on{background:var(--gold);border-color:var(--gold);color:#2a1d00}.sep{width:1px;height:22px;background:var(--line);margin:0 4px}
.reelb{margin-inline-start:auto;background:var(--acc);color:#04210f;border:0;border-radius:22px;padding:8px 16px;font:800 14px system-ui,sans-serif;cursor:pointer;box-shadow:0 4px 18px rgba(46,224,111,.25)}
.reelb:hover{filter:brightness(1.08)}
/* matches */
.mgrp{background:var(--card);border:1px solid var(--line);border-radius:14px;overflow:hidden;margin-bottom:12px}
.mgh{display:flex;align-items:center;gap:8px;padding:8px 14px;font-weight:700;font-size:14px;color:var(--mut);background:#0c1e14;border-bottom:1px solid var(--line)}
.mrw{display:grid;grid-template-columns:64px 1fr auto 1fr minmax(0,190px) auto;align-items:center;gap:10px;padding:9px 14px;border-top:1px solid #16301f;font-size:15px}
.mrw:first-of-type{border-top:0}.mrw[hidden],.mgrp[hidden]{display:none}
.mt2{color:var(--gold);font-weight:700;font-size:14px;font-variant-numeric:tabular-nums}.mt2.ft{color:var(--mut)}
.lvb{color:#ff5b5b;font-weight:800;font-size:12px}
.mtm{display:flex;align-items:center;gap:8px;font-weight:700;min-width:0}.mtm.h{justify-content:flex-end;text-align:end}
.mtm .tn{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.mtm img,.mtm .ini{width:22px;height:22px;object-fit:contain;flex:none}.ini{display:inline-grid;place-items:center;border-radius:50%;background:#1f3d2b;color:var(--mut);font:800 9px system-ui}
.mmid{min-width:52px;text-align:center}.vs{color:var(--mut);font-size:13px}
.sc{display:inline-block;background:var(--acc);color:#04210f;border-radius:8px;padding:1px 9px;font-weight:800;font-variant-numeric:tabular-nums}
.mtv{font-size:12px;color:var(--mut);line-height:1.35}
.mact{display:flex;align-items:center;gap:6px;justify-content:flex-end}
.hlb{background:none;border:1px solid var(--acc);color:var(--acc);border-radius:14px;padding:3px 10px;font:700 12px system-ui;cursor:pointer;white-space:nowrap}.hlb:hover{background:var(--acc);color:#04210f}
.trk{font-size:12px}.go{color:var(--mut);font-size:22px;line-height:1;padding:0 4px}.go:hover{color:var(--acc)}
@media(max-width:760px){.mtm img,.mtm .ini{display:none}.mtm .tn{white-space:normal;overflow:visible;line-height:1.25}.mrw{grid-template-columns:44px 1fr auto 1fr auto;gap:6px 8px;padding:9px 10px;font-size:14px}.mtv{grid-column:2/5;grid-row:2;text-align:center}.mact{grid-column:5;grid-row:1/3}}
/* trivia */
.trivia{background:linear-gradient(120deg,#183d22,#2a2a0c);border:1px solid #4b5a1f;border-radius:16px;padding:16px 18px}
.trivia .k{font:800 12px system-ui;letter-spacing:.6px;text-transform:uppercase;color:var(--gold)}.trivia .q{font-size:18px;font-weight:800;margin:6px 0 12px}
.topts{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:8px}
.topt{background:var(--bg);color:var(--txt);border:1px solid var(--line);border-radius:12px;padding:10px 12px;font:600 15px system-ui,sans-serif;cursor:pointer;text-align:start}
.topt:hover{border-color:var(--gold)}.topt.ok{background:#14532d;border-color:var(--acc)}.topt.no{background:#4a1515;border-color:#ff6b6b}
.tfact{margin:12px 0 0;color:var(--mut)}.tfact a{color:var(--gold);font-weight:700}
footer{border-top:1px solid var(--line);color:var(--mut);font-size:13px;padding:18px 16px;text-align:center}
footer a{color:var(--acc)}
/* modals */
.modal{position:fixed;inset:0;z-index:50;background:rgba(0,0,0,.78);display:grid;place-items:center;padding:16px}.modal[hidden]{display:none}
.mbox{background:var(--card);border:1px solid var(--line);border-radius:18px;width:min(640px,100%);max-height:90vh;display:flex;flex-direction:column;overflow:hidden}
.mbox.wide{width:min(980px,100%)}.mbox.reel{width:min(1200px,100%)}
.mhead{display:flex;align-items:center;gap:10px;padding:14px 16px;border-bottom:1px solid var(--line)}
.mhead b{flex:1;font-size:17px;line-height:1.3}.mhead small{color:var(--mut)}.x{background:none;border:0;color:var(--txt);font-size:22px;cursor:pointer}
.ptabs{display:flex;gap:6px;overflow-x:auto;padding:12px 16px 4px;scrollbar-width:none}
.ptab{flex:none;background:var(--bg);color:var(--mut);border:1px solid var(--line);border-radius:18px;padding:6px 12px;font:600 13px system-ui,sans-serif;cursor:pointer}
.ptab.on{background:var(--acc);color:#04210f;border-color:var(--acc)}
.pteams{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:8px;padding:12px 16px;overflow:auto}
.pteam{text-align:start;background:var(--bg);color:var(--txt);border:1px solid var(--line);border-radius:12px;padding:10px 12px;font:600 14px system-ui,sans-serif;cursor:pointer}
.pteam.on{border-color:var(--gold);background:#2a2a0c}
.mfoot{display:flex;align-items:center;justify-content:space-between;padding:12px 16px;border-top:1px solid var(--line)}
.done{background:var(--acc);color:#04210f;border:0;border-radius:20px;padding:9px 24px;font:800 15px system-ui,sans-serif;cursor:pointer}
.vwrap{position:relative;aspect-ratio:16/9;background:#000}.vwrap iframe,.vwrap .ytp{position:absolute;inset:0;width:100%;height:100%;border:0}
.ytbig{position:absolute;inset:0;display:grid;place-content:center;gap:12px;text-align:center;color:#fff;font-size:44px;background:radial-gradient(#3a0d0d,#000);padding:16px}
.ytbig span{font-size:18px;font-weight:700;background:#e62117;border-radius:24px;padding:10px 22px;justify-self:center}.ytbig small{font-size:14px;color:#ccc;max-width:420px}
.yt{margin:0;padding:10px 16px;font-size:14px;display:flex;flex-wrap:wrap;gap:8px 14px;align-items:center}.yt a{color:var(--acc)}
.paud{display:flex;gap:6px;align-items:center}
.reelg{display:grid;grid-template-columns:1fr 300px;min-height:0}.reelg .vwrap{align-self:start}
.rq{list-style:none;margin:0;padding:8px;overflow:auto;max-height:60vh;border-inline-start:1px solid var(--line)}
.rq li{display:grid;grid-template-columns:96px 1fr;gap:8px;padding:6px;border-radius:10px;cursor:pointer;font-size:13px;font-weight:600;line-height:1.3}
.rq li img{width:96px;aspect-ratio:16/9;object-fit:cover;border-radius:6px}.spoilfree .rq li img{filter:blur(8px)}
.rq li.on{background:#173d25;outline:1px solid var(--acc)}.rq li:hover{background:#12301f}.rq li.skip{opacity:.4}
.rbtn{background:var(--bg);color:var(--txt);border:1px solid var(--line);border-radius:16px;padding:5px 12px;font:700 13px system-ui;cursor:pointer}
@media(max-width:820px){.reelg{grid-template-columns:1fr}.rq{max-height:30vh;border:0;border-top:1px solid var(--line)}}
.gpop .gbody{padding:16px 18px;overflow:auto;line-height:1.6}.gpop .gbody a{color:var(--gold);font-weight:700}
.langpick{background:var(--card);color:var(--txt);border:1px solid var(--line);border-radius:10px;padding:7px 10px;font:600 14px system-ui,sans-serif}
.brand .fa-tools{margin-inline-start:auto}
[dir=rtl] .mtm.h{justify-content:flex-start}[dir=rtl] .mtm.h{text-align:start}
:lang(ar) body,:lang(ar) .chip,:lang(ar) .more{font-family:"Segoe UI",Tahoma,"Noto Sans Arabic",system-ui,sans-serif}
</style></head><body>
<header><div class="wrap brand"><img src="logo.png" alt="Football Arena" width="52" height="52"><div><h1>FOOTBALL <span>ARENA</span></h1>
<div class="tag" data-i18n="tagline">Highlights & news from the world's biggest leagues · updated every hour</div></div>
<select class="langpick" aria-label="Language"></select></div></header>
<div class="bar"><div class="wrap">
<nav><a href="#highlights" data-i18n="nav_hl">Highlights</a><a class="livelink" href="live.html" data-i18n="nav_live">Live</a><a href="#matches" data-i18n="nav_fix">Matches</a><a href="tables.html" data-i18n="nav_tables">Tables</a><a href="#news" data-i18n="nav_news">News</a><a href="articles/index.html" data-i18n="nav_art">Articles</a><a class="quiz" href="quiz.html" data-i18n="nav_quiz">Quiz</a><a href="https://www.facebook.com/1429286323597310" target="_blank" rel="noopener" data-i18n="nav_fb">Facebook</a></nav><script>(function(){var t=function(p){return p.replace(/index\\.html$/,"")},here=t(location.pathname),L=document.querySelectorAll("nav a"),m=null,d=null;L.forEach(function(a){if(a.host!==location.host)return;var ap=t(a.pathname);if(ap===here&&!m&&(!a.hash||a.hash==="#highlights"))m=a;if(!d&&ap!=="/"&&ap.slice(-1)==="/"&&here.indexOf(ap)===0)d=a;});if(m||d)(m||d).classList.add("on");})();</script>
<div class="chips">{{CHIPS}}</div>
</div></div>
<main class="wrap">
<section id="highlights"><div class="shead"><h2><span data-i18n="h_hl">Latest Highlights</span> <span class="count"></span></h2>
<button class="reelb" id="reelb" type="button">▶ <span data-i18n="reel">Play Matchday Reel</span> (<span id="reeln">0</span>)</button></div>
<div class="tools"><span data-i18n="cm_hl">🎙️ Commentary:</span> {{CM}}<span class="sep"></span><span data-i18n="sort">Sort:</span>
<button class="srt on" data-o="ts" data-i18n="s_latest">Latest</button><button class="srt" data-o="thrill" data-i18n="s_thrill">🔥 Most exciting</button></div>
<div class="grid" id="vgrid" data-show="8">
{{VIDEOS}}
</div><button class="more" data-i18n="more_hl">Show more highlights</button></section>
<section id="trivia" hidden></section>
<section id="matches"><div class="shead"><h2><span data-i18n="h_fix">Upcoming Matches & TV Channels</span> <span class="mcount count"></span></h2>
<select class="tvpick" aria-label="TV region"></select></div>
<div class="ribbon" id="rib"></div><div class="cdown" id="cd" hidden></div>
<div id="mlist">
{{MATCHES}}
</div><p class="empty" id="noday" hidden data-i18n="no_day">No matches on this day.</p>
<p class="fnote" style="color:var(--mut);font-size:13px" data-i18n="fix_note">Times are shown in your local time. TV channels can change – please check your local listings.</p>
<p><a href="matches/index.html" style="color:var(--acc)" data-i18n="m_all">All matches</a> →</p></section>
<section id="news"><h2><span data-i18n="h_news">Latest Football News</span> <span class="count"></span></h2><div class="grid" data-show="9">
{{NEWS}}
</div><button class="more" data-i18n="more_news">Show more news</button></section>
<section id="articles"><h2 data-i18n="h_art">Football Articles</h2><div class="grid">
{{ARTICLES}}
</div><p><a href="articles/index.html" style="color:var(--acc)" data-i18n="see_art">See all articles →</a></p></section>
</main>
<footer><span data-i18n="updated">Updated</span> {{UPDATED}} · <span data-i18n="foot">Videos play on the official YouTube channels of each league. News headlines link to the original
publishers (BBC Sport, The Guardian, ESPN). All rights belong to their owners.</span><br>
<a href="about.html" data-i18n="about">About</a> · <a href="contact.html" data-i18n="contact">Contact</a> · <a href="privacy.html" data-i18n="privacy">Privacy</a></footer>
<div class="modal" id="picker" hidden><div class="mbox"><div class="mhead"><b data-i18n="pick_teams">Pick your favourite teams</b>
<button class="x" data-close aria-label="Close">✕</button></div><div class="ptabs" id="ptabs"></div><div class="pteams" id="pteams"></div>
<div class="mfoot"><span class="meta" id="pcount"></span><button class="done" id="pdone" data-i18n="done">Done</button></div></div></div>
<div class="modal" id="player" hidden><div class="mbox wide"><div class="mhead"><b id="ptitle"></b><button class="x" data-close aria-label="Close">✕</button></div>
<div class="vwrap" id="vwrap"></div><p class="yt"><span class="paud" id="paud"></span><a id="ytlink" href="#" target="_blank" rel="noopener" data-i18n="yt_fallback">Video not playing? Watch it on YouTube</a></p></div></div>
<div class="modal" id="reel" hidden><div class="mbox reel"><div class="mhead"><b id="rtitle"></b><small id="rpos"></small><button class="x" data-close aria-label="Close">✕</button></div>
<div class="reelg"><div class="vwrap" id="rwrap"></div><ol class="rq" id="rq"></ol></div>
<p class="yt"><button class="rbtn" id="rprev">⏮</button><button class="rbtn" id="rnext">⏭</button><small style="color:var(--mut)" data-i18n="reel_keys">N next · P previous · S spoiler-free</small></p></div></div>
<div class="modal gpop" id="gpop" hidden><div class="mbox"><div class="mhead"><b id="gtitle"></b><button class="x" data-close aria-label="Close">✕</button></div><div class="gbody" id="gbody"></div></div></div>
<script id="teams-data" type="application/json">{{TEAMS}}</script>
<script id="site-data" type="application/json">{{DATA}}</script>
<script src="i18n.js"></script><script src="fa.js"></script>
<script>
(function(){
  "use strict";
  var $ = function(s, r){ return (r || document).querySelector(s); }, $$ = function(s, r){ return [].slice.call((r || document).querySelectorAll(s)); };
  var LS = FAX.ls, filter = "all";
  var TEAMS = []; try { TEAMS = JSON.parse($("#teams-data").textContent); } catch(e) {}
  var DATA = {}; try { DATA = JSON.parse($("#site-data").textContent); } catch(e) {}
  function getMine(){ return FAX.mine(); }
  function esc(x){ return x.replace(/[^a-z0-9 &'\\-\\u0600-\\u06ff]/g, ""); }
  var mineRe = null;
  function buildRe(){
    var keys = [];
    getMine().forEach(function(n){ TEAMS.forEach(function(t){ if (t.name === n) keys = keys.concat(t.keys); }); });
    mineRe = keys.length ? new RegExp("(^|[^a-z0-9\\u0600-\\u06ff])(" + keys.map(esc).join("|") + ")($|[^a-z0-9\\u0600-\\u06ff])") : null;
  }
  buildRe();
  function ok(c){ return filter === "all" || (filter === "my" ? !!(mineRe && mineRe.test(c.dataset.s || "")) : c.dataset.l === filter); }

  /* ---------- commentary language: cards with several versions switch to the chosen one */
  var cmf = LS.get("fa_cm", "all");
  function pickVersion(card, lg){
    var b = $('.ab[data-lg="' + lg + '"]', card); if (!b) return;
    $$(".ab", card).forEach(function(x){ x.classList.toggle("on", x === b); });
    card.href = "https://www.youtube.com/watch?v=" + b.dataset.v;
    $("img", card).src = "https://i.ytimg.com/vi/" + b.dataset.v + "/hqdefault.jpg";
    var vt = $(".vt", card); vt.dataset.o = b.dataset.o; if (!FAX.spoil) vt.textContent = b.dataset.o;
  }
  $$(".cmb").forEach(function(b){
    b.classList.toggle("on", b.dataset.c === cmf);
    b.onclick = function(){
      cmf = b.dataset.c; LS.set("fa_cm", cmf);
      $$(".cmb").forEach(function(x){ x.classList.toggle("on", x === b); });
      if (cmf !== "all") $$("a.vid").forEach(function(c){ pickVersion(c, cmf); });
      $$(".grid[data-show]").forEach(function(g){ g.dataset.limit = ""; });
      apply();
    };
  });
  if (!$(".cmb.on")) { cmf = "all"; $(".cmb").classList.add("on"); }
  if (cmf !== "all") $$("a.vid").forEach(function(c){ pickVersion(c, cmf); });

  /* ---------- show / hide cards */
  function apply(){
    $$(".grid[data-show]").forEach(function(g){
      var lim = +g.dataset.limit || +g.dataset.show, total = 0;
      $$(".card", g).forEach(function(c){
        var good = ok(c);
        if (cmf !== "all" && c.dataset.c && c.dataset.c.split(" ").indexOf(cmf) < 0) good = false;
        if (!good) { c.classList.add("hide"); return; }
        total++;
        c.classList.toggle("hide", total > lim);
      });
      var shown = $$(".card:not(.hide)", g).length, sec = g.closest("section");
      $(".more", sec).style.display = shown < total ? "" : "none";
      $(".count", sec).textContent = total ? "(" + total + ")" : "";
      var em = $(".none", g);
      if (!total && !em){ em = document.createElement("p"); em.className = "empty none"; g.appendChild(em); }
      if (em){ var k = filter === "my" ? "no_my" : "none"; em.setAttribute("data-i18n", k); em.textContent = FA.t(k); em.style.display = total ? "none" : ""; }
    });
    $("#reeln").textContent = reelList().length;
    showMatches(); trivia();
  }
  function setChip(f, save){
    filter = f;
    $$(".chip").forEach(function(x){ x.classList.toggle("on", x.dataset.f === f); });
    if (save) { LS.set("fa_filter", f); try { history.replaceState(null, "", f === "all" ? location.pathname : "#" + f); } catch(e) {} }
    $$(".grid[data-show]").forEach(function(g){ g.dataset.limit = ""; });
    apply();
  }
  $$(".chip").forEach(function(b){
    b.onclick = function(){
      if (b.dataset.f === "my" && (!getMine().length || filter === "my")) { openPicker(); return; }
      setChip(b.dataset.f, true);
    };
  });
  $$(".more").forEach(function(m){
    m.onclick = function(){ var g = m.previousElementSibling; g.dataset.limit = (+g.dataset.limit || +g.dataset.show) + 12; apply(); };
  });

  /* ---------- sort: latest | most exciting */
  var order = LS.get("fa_sort", "ts");
  function sortCards(){
    var g = $("#vgrid"), cards = $$("a.vid", g);
    cards.sort(function(a, b){ return order === "thrill" ? (+b.dataset.thrill - +a.dataset.thrill) || (+b.dataset.ts - +a.dataset.ts) : +b.dataset.ts - +a.dataset.ts; });
    cards.forEach(function(c){ g.appendChild(c); });
    $$(".srt").forEach(function(x){ x.classList.toggle("on", x.dataset.o === order); });
  }
  $$(".srt").forEach(function(b){ b.onclick = function(){ order = b.dataset.o; LS.set("fa_sort", order); sortCards(); $("#vgrid").dataset.limit = ""; apply(); }; });
  sortCards();

  /* ---------- My Teams picker */
  var picker = $("#picker"), ptabs = $("#ptabs"), pteams = $("#pteams");
  var LG = [["eng","Premier League"],["esp","LaLiga"],["ita","Serie A"],["ger","Bundesliga"],["fra","Ligue 1"],["ksa","Saudi Pro League"],["eur","Europe"]];
  var cur = "eng";
  function drawPicker(){
    var mine = getMine();
    ptabs.innerHTML = LG.filter(function(l){ return TEAMS.some(function(t){ return t.l === l[0]; }); }).map(function(l){
      return '<button class="ptab' + (l[0] === cur ? ' on' : '') + '" data-l="' + l[0] + '">' + l[1] + '</button>'; }).join("");
    pteams.innerHTML = TEAMS.filter(function(t){ return t.l === cur; }).map(function(t){
      var on = mine.indexOf(t.name) >= 0;
      return '<button class="pteam' + (on ? ' on' : '') + '" data-n="' + t.name.replace(/"/g, "&quot;") + '">' + (on ? "⭐ " : "☆ ") + t.name + '</button>'; }).join("") || '<p class="meta">⏳</p>';
    $("#pcount").textContent = mine.length ? "⭐ " + mine.length : "";
    $$(".ptab", ptabs).forEach(function(b){ b.onclick = function(){ cur = b.dataset.l; drawPicker(); }; });
    $$(".pteam", pteams).forEach(function(b){ b.onclick = function(){
      var m = getMine(), i = m.indexOf(b.dataset.n); if (i >= 0) m.splice(i, 1); else m.push(b.dataset.n); FAX.setMine(m); drawPicker(); }; });
  }
  function openPicker(){ drawPicker(); picker.hidden = false; }
  $("#pdone").onclick = function(){ picker.hidden = true; buildRe(); setChip(getMine().length ? "my" : "all", true); };
  document.addEventListener("fa:teams", function(){ buildRe(); apply(); });

  /* ---------- video player with instant YouTube fallback */
  var player = $("#player"), vwrap = $("#vwrap");
  var noEmbed = {}; try { noEmbed = JSON.parse(LS.get("fa_noembed", "{}")); } catch(e) {}
  function markNoEmbed(id){ noEmbed[id] = 1; LS.set("fa_noembed", JSON.stringify(noEmbed));
    $$('a.vid').forEach(function(c){ if ($('.ab[data-v="' + id + '"]', c) || c.href.indexOf(id) > 0) c.dataset.ext = "1"; });
    $("#reeln").textContent = reelList().length; }
  $$("a.vid").forEach(function(c){ var m = c.href.match(/v=([\\w-]+)/); if (m && noEmbed[m[1]]) c.dataset.ext = "1"; });
  var ytReady = null;
  function loadYT(){
    if (ytReady) return ytReady;
    ytReady = new Promise(function(res, rej){
      if (window.YT && window.YT.Player) return res();
      window.onYouTubeIframeAPIReady = res;
      var sc = document.createElement("script"); sc.src = "https://www.youtube.com/iframe_api"; sc.onerror = rej;
      document.head.appendChild(sc); setTimeout(rej, 6000);
    });
    return ytReady;
  }
  function popup(url){
    var w = 960, h = 540, x = Math.max(0, (screen.width - w) / 2), y = Math.max(0, (screen.height - h) / 2);
    return window.open(url, "fa_yt", "width=" + w + ",height=" + h + ",left=" + x + ",top=" + y + ",noopener");
  }
  function fallback(box, url){
    box.innerHTML = '<a class="ytbig" href="' + url + '" target="_blank" rel="noopener">▶ <span>' + FA.t("yt_watch") + "</span><small>" + FA.t("popup") + "</small></a>";
  }
  function makePlayer(box, id, onEnd, onFail){
    box.innerHTML = '<div class="ytp"></div>';
    var url = "https://www.youtube.com/watch?v=" + id;
    loadYT().then(function(){
      new YT.Player($(".ytp", box), {videoId: id, host: "https://www.youtube-nocookie.com", playerVars: {autoplay: 1, rel: 0, playsinline: 1},
        events: {onError: function(ev){ if (ev.data === 101 || ev.data === 150 || ev.data === 100) markNoEmbed(id); onFail ? onFail(url) : fallback(box, url); },
                 onStateChange: function(ev){ if (ev.data === 0 && onEnd) onEnd(); }}});
    }).catch(function(){
      box.innerHTML = '<iframe src="https://www.youtube-nocookie.com/embed/' + id + '?autoplay=1&rel=0" title="Highlights" allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowfullscreen></iframe>';
    });
  }
  function openCard(card){
    var id = (card.href.match(/v=([\\w-]+)/) || [])[1]; if (!id) return;
    $("#ptitle").textContent = $(".vt", card).textContent;
    $("#ytlink").href = card.href;
    var abs = $$(".ab", card);
    $("#paud").innerHTML = abs.length > 1 ? "🎙️ " + abs.map(function(b){ return '<b class="ab' + (b.classList.contains("on") ? " on" : "") + '" data-v="' + b.dataset.v + '" data-lg="' + b.dataset.lg + '">' + b.textContent + "</b>"; }).join("") : "";
    $$("#paud .ab").forEach(function(b){ b.onclick = function(){ pickVersion(card, b.dataset.lg); openCard(card); }; });
    player.hidden = false;
    makePlayer(vwrap, id, null, function(url){ fallback(vwrap, url); popup(url); });
  }
  window.FAplay = function(id){
    var card = $$("a.vid").filter(function(c){ return c.href.indexOf(id) > 0 || $('.ab[data-v="' + id + '"]', c); })[0];
    if (card) return openCard(card);
    $("#ptitle").textContent = ""; $("#ytlink").href = "https://www.youtube.com/watch?v=" + id; $("#paud").innerHTML = "";
    player.hidden = false; makePlayer(vwrap, id);
  };
  document.addEventListener("click", function(ev){
    var ab = ev.target.closest("a.vid .ab"); if (ab) { ev.preventDefault(); ev.stopPropagation(); pickVersion(ab.closest("a.vid"), ab.dataset.lg); return; }
    var tac = ev.target.closest(".tac"); if (tac) { ev.preventDefault(); ev.stopPropagation(); guide(tac.dataset.g); return; }
    var src = ev.target.closest(".src"); if (src) { ev.preventDefault(); ev.stopPropagation(); window.open(src.dataset.u, "_blank", "noopener"); return; }
    var hb = ev.target.closest(".hlb"); if (hb) { ev.preventDefault(); window.FAplay(hb.dataset.v); return; }
    var card = ev.target.closest("a.vid"); if (!card) return;
    if (card.dataset.ext) { if (popup(card.href)) ev.preventDefault(); return; }  // owner blocks embedding: open YouTube straight away
    ev.preventDefault(); openCard(card);
  });

  /* ---------- matchday reel: every playable highlight for the current filter, back to back */
  var reel = $("#reel"), rq = $("#rq"), rwrap = $("#rwrap"), queue = [], pos = 0;
  function reelList(){ return $$("a.vid").filter(function(c){ return ok(c) && !c.dataset.ext && (cmf === "all" || c.dataset.c.split(" ").indexOf(cmf) >= 0); }); }
  function rplay(i){
    if (!queue.length) return; pos = (i + queue.length) % queue.length;
    var c = queue[pos], id = (c.href.match(/v=([\\w-]+)/) || [])[1];
    $("#rtitle").textContent = $(".vt", c).textContent; $("#rpos").textContent = (pos + 1) + " / " + queue.length;
    $$("li", rq).forEach(function(li, j){ li.classList.toggle("on", j === pos); if (j === pos) li.scrollIntoView({block: "nearest"}); });
    makePlayer(rwrap, id, function(){ rplay(pos + 1); }, function(){ $$("li", rq)[pos].classList.add("skip"); setTimeout(function(){ rplay(pos + 1); }, 600); });
  }
  function openReel(){
    queue = reelList(); if (!queue.length) return;
    rq.innerHTML = queue.map(function(c, i){ var id = (c.href.match(/v=([\\w-]+)/) || [])[1];
      return '<li data-i="' + i + '"><img src="https://i.ytimg.com/vi/' + id + '/mqdefault.jpg" alt="" loading="lazy"><span>' + $(".vt", c).textContent.replace(/</g, "&lt;") + "</span></li>"; }).join("");
    $$("li", rq).forEach(function(li){ li.onclick = function(){ rplay(+li.dataset.i); }; });
    reel.hidden = false; rplay(0);
  }
  $("#reelb").onclick = openReel; $("#rnext").onclick = function(){ rplay(pos + 1); }; $("#rprev").onclick = function(){ rplay(pos - 1); };
  document.addEventListener("keydown", function(ev){
    if (/input|select|textarea/i.test(ev.target.tagName)) return;
    if (ev.key === "Escape") closeAll();
    if (reel.hidden) return;
    var k = ev.key.toLowerCase();
    if (k === "n") rplay(pos + 1); else if (k === "p") rplay(pos - 1);
    else if (k === "s") { FAX.setSpoil(!FAX.spoil); }
  });
  document.addEventListener("fa:spoil", function(){
    if (!reel.hidden && queue[pos]) { $("#rtitle").textContent = $(".vt", queue[pos]).textContent;
      $$("li span", rq).forEach(function(s, j){ s.textContent = $(".vt", queue[j]).textContent; }); }
    if (!player.hidden) $("#ptitle").textContent = $("#ptitle").textContent;
  });

  /* ---------- tactical guide popover */
  function guide(slug){
    var g = (DATA.guides || {})[slug]; if (!g) return;
    $("#gtitle").textContent = "💡 " + g.t;
    $("#gbody").innerHTML = "<p>" + g.x.replace(/</g, "&lt;") + '</p><p><a href="' + g.u + '">' + FA.t("read_guide") + "</a></p>";
    $("#gpop").hidden = false;
  }

  /* ---------- matchday warm-up trivia (follows the league filter) */
  var tq = null;
  function trivia(){
    var Q = DATA.quiz || [], box = $("#trivia"); if (!Q.length) return;
    var lg = /^(eng|esp|ita|ger|fra|eur|wld)$/.test(filter) ? filter : null;
    var pool = Q.filter(function(q){ return !lg || q.l === lg; }); if (!pool.length) pool = Q;
    var day = Math.floor(Date.now() / 864e5), q = pool[day % pool.length];
    if (tq === q && box.innerHTML) return; tq = q;
    var tr = window.FA_QUIZ && FA_QUIZ[FA.lang] && FA_QUIZ[FA.lang][q.i], text = tr ? tr[0] : q.q, fact = tr ? tr[1] : q.f;
    var opts = q.o.map(function(o, i){ return [o, i]; }).sort(function(a, b){ return ((a[1] * 7 + day) % 5) - ((b[1] * 7 + day) % 5); });
    box.innerHTML = '<div class="trivia"><div class="k">🧠 ' + FA.t("trivia") + '</div><div class="q">' + text.replace(/</g, "&lt;") + '</div><div class="topts">' +
      opts.map(function(o){ return '<button class="topt" data-r="' + (o[1] === 0 ? 1 : 0) + '">' + o[0].replace(/</g, "&lt;") + "</button>"; }).join("") + "</div></div>";
    box.hidden = false;
    $$(".topt", box).forEach(function(b){ b.onclick = function(){
      $$(".topt", box).forEach(function(x){ x.disabled = true; if (x.dataset.r === "1") x.classList.add("ok"); });
      if (b.dataset.r !== "1") b.classList.add("no");
      var p = document.createElement("p"); p.className = "tfact";
      p.innerHTML = (b.dataset.r === "1" ? "✅ " : "❌ ") + fact.replace(/</g, "&lt;") + ' <a href="quiz.html">' + FA.t("trivia_more") + "</a>";
      $(".trivia", box).appendChild(p); }; });
  }
  if (FA.lang !== "en" && !window.FA_QUIZ) { var qs = document.createElement("script"); qs.src = "quiz_i18n.js"; qs.onload = function(){ tq = null; trivia(); }; document.head.appendChild(qs); }

  /* ---------- matches: day ribbon, countdown, local kick-off times, TV region */
  var mday = null, mrows = $$(".mrw");
  function localTimes(){
    var L = FA.lang === "ar" ? "ar-MA" : FA.lang;
    $$(".mt2[data-k]").forEach(function(s){ try { s.textContent = new Date(s.dataset.k * 1000).toLocaleTimeString(L, {hour: "2-digit", minute: "2-digit", hour12: false}); } catch(e) {} });
  }
  function showMatches(){
    if (!mrows.length || !mday) return;
    var n = 0, now = Date.now() / 1000;
    mrows.forEach(function(r){ var good = FAX.dayKey(new Date(r.dataset.k * 1000)) === mday && ok(r); r.hidden = !good; if (good) n++; });
    $$(".mgrp").forEach(function(g){ g.hidden = !$$(".mrw", g).some(function(r){ return !r.hidden; }); });
    $("#noday").hidden = n > 0; $(".mcount").textContent = n ? "(" + n + ")" : "";
    var next = mrows.filter(function(r){ return r.dataset.st === "pre" && +r.dataset.k > now && ok(r); })[0], cd = $("#cd");
    cd.hidden = !next;
    if (next) FAX.countdown(cd, +next.dataset.k, $(".mtm.h .tn", next).textContent + " vs " + $(".mtm.a .tn", next).textContent);
  }
  function ribbon(){ FAX.ribbon($("#rib"), mrows.map(function(r){ return +r.dataset.k; }), function(k){ mday = k; showMatches(); }, mday); }
  localTimes(); ribbon();
  document.addEventListener("fa:lang", function(){ localTimes(); ribbon(); tq = null; trivia(); });

  /* ---------- close buttons */
  function closeAll(){ $$(".modal").forEach(function(m){ m.hidden = true; }); vwrap.innerHTML = ""; rwrap.innerHTML = ""; }
  $$("[data-close]").forEach(function(b){ b.onclick = closeAll; });
  $$(".modal").forEach(function(m){ m.addEventListener("click", function(ev){ if (ev.target === m) closeAll(); }); });

  /* ---------- start: link > saved choice */
  var h = location.hash.slice(1), start = $('.chip[data-f="' + h + '"]') ? h : FAX.filter();
  if (start === "my" && !getMine().length) { if (h === "my") openPicker(); start = "all"; }
  setChip($('.chip[data-f="' + start + '"]') ? start : "all", false);
  document.addEventListener("fa:filter", function(e){ if (e.detail !== filter) setChip(e.detail, false); });
})();
</script>
</body></html>"""
