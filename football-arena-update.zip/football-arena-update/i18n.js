/* Football Arena – site languages. Add a language: copy the "en" block, translate it, add it to LANGS. */
(function () {
var LANGS = [["en", "English"], ["ar", "العربية"], ["fr", "Français"], ["es", "Español"], ["pt", "Português"], ["de", "Deutsch"], ["it", "Italiano"]];
var T = {
en: {m_table: "League table", m_all_tables: "See the full league tables →", m_related: "Related highlights & news", m_all: "All matches", m_kick: "Kick-off", m_venue: "Stadium", m_watch: "Where to watch on TV", m_h1: "Football Matches: Live Scores, Kick-off Times & TV Channels", m_intro: "Every big match in the Premier League, LaLiga, Serie A, Bundesliga, Ligue 1, Champions League and Europa League.", m_upcoming: "Upcoming & live", m_recent: "Recent results",
 yt_watch: "Watch on YouTube", my_teams: "My Teams", pick_teams: "Pick your favourite teams", done: "Done", yt_fallback: "Video not playing? Watch it on YouTube", no_my: "Nothing for your teams here right now. Tap ⭐ My Teams again to change your teams.", nav_tables: "Tables", h_tables: "League Tables & Top Scorers", tables_intro: "Standings, top scorers and top assists for the biggest leagues – updated every hour.", t_team: "Team", t_p: "P", t_w: "W", t_d: "D", t_l: "L", t_gd: "GD", t_pts: "Pts", t_player: "Player", t_scorers: "Top scorers", t_assists: "Top assists", t_goals: "Goals", t_ast: "Assists",
 nav_live: "Live", watch: "Live tracker", lv_title: "🔴 Live Match Tracker", lv_intro: "Follow the big matches live as a cartoon – score, minute, goals, cards and stats update every 30 seconds.", lv_none: "No big matches right now or in the next day.", lv_sched: "See the match schedule", lv_ft: "FT", lv_kick: "Kick-off at {time}", lv_stats: "Match stats", lv_events: "Key moments", lv_src: "Updates automatically every 30 seconds. Cartoon view based on live match data – not real match footage.", lv_goal: "GOAL!", lv_wait: "The match hasn't started yet.", lv_noev: "No big moments yet.", st_pos: "Possession", st_shots: "Shots", st_target: "On target", st_corners: "Corners", st_fouls: "Fouls", st_yellow: "Yellow cards", ev_goal: "GOAL for {team}! {p} scores.", ev_goal_a: "GOAL for {team}! {p} scores, assisted by {a}.", ev_pen: "Penalty goal for {team}! {p} scores from the spot.", ev_og: "Own goal by {p}.", ev_red: "Red card! {p} ({team}) is sent off.", ev_yellow: "Yellow card for {p} ({team}).", ev_sub: "Substitution for {team}: {p}.", ev_ko: "Kick-off! The match is under way.", ev_ht: "Half-time.", ev_2h: "The second half is under way.", ev_ft: "Full time!", cm_hl: "🎙️ Commentary:", cm_title: "🎙️ Live commentator", cm_off: "Off", cm_note: "Pick a commentator to hear goals, cards and big moments read out loud.", cm_novoice: "No voice for this language on your device – the commentary is shown as text below.", cm_hello: "Hello and welcome to Football Arena! {home} against {away}. {score}", cm_score: "The score is {h} – {a}.", cm_pre: "Kick-off is coming soon.", cm_min: "{min} minutes.",
 live: "LIVE", nav_fix: "Matches", h_fix: "Upcoming Matches & TV Channels", fix_note: "Times are shown in your local time. TV channels can change – please check your local listings.", more_fix: "Show more matches", tv_mena: "Arab world & North Africa", tv_usa: "USA", tv_check: "Check your local TV listings", no_fix: "No matches scheduled in the next few days.",
 nav_hl: "Highlights", nav_news: "News", nav_art: "Articles", nav_quiz: "Quiz", nav_fb: "Facebook", nav_about: "About",
 tagline: "Highlights & news from the world's biggest leagues · updated every hour",
 all: "All", c_eng: "England", c_esp: "Spain", c_ita: "Italy", c_ger: "Germany", c_fra: "France", c_eur: "Europe", c_wld: "World",
 lg_eng: "Premier League", lg_esp: "LaLiga", lg_ita: "Serie A", lg_ger: "Bundesliga", lg_fra: "Ligue 1", lg_eur: "Champions League & UEFA", lg_wld: "FIFA & International",
 h_hl: "Latest Highlights", h_news: "Latest Football News", h_art: "Football Articles", see_art: "See all articles →",
 more_hl: "Show more highlights", more_news: "Show more news", none: "Nothing for this league right now – check back soon.",
 qb_t: "How well do you know football?", qb_p: "Play our quiz by country and league – learn a fun fact with every answer.", qb_btn: "Play the quiz",
 updated: "Updated", foot: "Videos play on the official YouTube channels of each league. News headlines link to the original publishers (BBC Sport, The Guardian, ESPN). All rights belong to their owners.",
 about: "About", contact: "Contact", privacy: "Privacy", ago_m: "{n} min ago", ago_h: "{n} h ago", ago_d: "{n} d ago",
 art_note: "", qz_title: "🧠 Football Quiz", qz_intro: "Pick a country or league, answer 10 questions, and learn a fun fact with every answer.",
 qz_q: "Question {i} of {n}", qz_score: "Score", qz_next: "Next question →", qz_see: "See my score", qz_ok: "Correct!", qz_no: "Not quite. The answer is",
 qz_your: "Your score", qz_m1: "Perfect! You are a football genius 🏆", qz_m2: "Great job – you really know your football! ⚽", qz_m3: "Not bad! Play again to learn more 💪",
 qz_m4: "Keep watching and reading – you'll get there! 📚", qz_again: "Play again", qz_share: "Share on Facebook",
 qz_more: "Want to learn more? Read our <a href='articles/index.html'>football articles</a> or watch the <a href='index.html#highlights'>latest highlights</a>."},
ar: {m_table: "جدول الترتيب", m_all_tables: "شاهد جداول الترتيب كاملة ←", m_related: "ملخصات وأخبار ذات صلة", m_all: "كل المباريات", m_kick: "موعد المباراة", m_venue: "الملعب", m_watch: "القنوات الناقلة", m_h1: "مباريات كرة القدم: النتائج المباشرة والمواعيد والقنوات الناقلة", m_intro: "كل المباريات الكبرى في الدوري الإنجليزي والإسباني والإيطالي والألماني والفرنسي ودوري الأبطال والدوري الأوروبي.", m_upcoming: "القادمة والمباشرة", m_recent: "آخر النتائج",
 yt_watch: "شاهده على يوتيوب", my_teams: "فرقي", pick_teams: "اختر فرقك المفضلة", done: "تم", yt_fallback: "الفيديو لا يعمل؟ شاهده على يوتيوب", no_my: "لا يوجد شيء لفرقك هنا الآن. اضغط على ⭐ فرقي مجددًا لتغيير فرقك.", nav_tables: "الترتيب", h_tables: "جداول الترتيب والهدافون", tables_intro: "الترتيب والهدافون وصنّاع الأهداف لأكبر الدوريات – يتحدث كل ساعة.", t_team: "الفريق", t_p: "لعب", t_w: "فوز", t_d: "تعادل", t_l: "خسارة", t_gd: "الفارق", t_pts: "نقاط", t_player: "اللاعب", t_scorers: "الهدافون", t_assists: "صنّاع الأهداف", t_goals: "أهداف", t_ast: "تمريرات حاسمة",
 nav_live: "مباشر", watch: "تتبع مباشر", lv_title: "🔴 تتبع المباريات مباشرة", lv_intro: "تابع المباريات الكبرى مباشرة بشكل كرتوني – النتيجة والدقيقة والأهداف والبطاقات والإحصائيات تتحدث كل 30 ثانية.", lv_none: "لا توجد مباريات كبرى الآن أو خلال اليوم القادم.", lv_sched: "اطّلع على جدول المباريات", lv_ft: "انتهت", lv_kick: "ضربة البداية الساعة {time}", lv_stats: "إحصائيات المباراة", lv_events: "أبرز اللحظات", lv_src: "تتحدث تلقائيًا كل 30 ثانية. عرض كرتوني مبني على بيانات المباراة المباشرة – وليس لقطات حقيقية.", lv_goal: "هدف!", lv_wait: "لم تبدأ المباراة بعد.", lv_noev: "لا توجد لحظات بارزة بعد.", st_pos: "الاستحواذ", st_shots: "التسديدات", st_target: "على المرمى", st_corners: "الركنيات", st_fouls: "الأخطاء", st_yellow: "البطاقات الصفراء", ev_goal: "هدف لـ{team}! {p} يسجّل.", ev_goal_a: "هدف لـ{team}! {p} يسجّل بتمريرة من {a}.", ev_pen: "هدف من ركلة جزاء لـ{team}! {p} يسجّل.", ev_og: "هدف عكسي عن طريق {p}.", ev_red: "بطاقة حمراء! طرد {p} ({team}).", ev_yellow: "بطاقة صفراء لـ{p} ({team}).", ev_sub: "تبديل لـ{team}: {p}.", ev_ko: "ضربة البداية! انطلقت المباراة.", ev_ht: "نهاية الشوط الأول.", ev_2h: "انطلق الشوط الثاني.", ev_ft: "نهاية المباراة!", cm_hl: "🎙️ التعليق:", cm_title: "🎙️ المعلّق المباشر", cm_off: "إيقاف", cm_note: "اختر المعلّق لتسمع الأهداف والبطاقات وأبرز اللحظات بصوت عالٍ.", cm_novoice: "لا يوجد صوت لهذه اللغة على جهازك – التعليق معروض كنص في الأسفل.", cm_hello: "مرحبًا بكم في فوتبول أرينا! {home} ضد {away}. {score}", cm_score: "النتيجة {h} – {a}.", cm_pre: "المباراة ستنطلق قريبًا.", cm_min: "الدقيقة {min}.",
 live: "مباشر", nav_fix: "المباريات", h_fix: "المباريات القادمة والقنوات الناقلة", fix_note: "المواعيد معروضة حسب توقيتك المحلي. قد تتغير القنوات الناقلة – يرجى التحقق من الدليل المحلي.", more_fix: "عرض المزيد من المباريات", tv_mena: "العالم العربي وشمال أفريقيا", tv_usa: "الولايات المتحدة", tv_check: "تحقق من دليل القنوات المحلي", no_fix: "لا توجد مباريات مقررة في الأيام القليلة القادمة.",
 nav_hl: "الملخصات", nav_news: "الأخبار", nav_art: "مقالات", nav_quiz: "اختبار", nav_fb: "فيسبوك", nav_about: "من نحن",
 tagline: "ملخصات وأخبار أكبر الدوريات في العالم · تحديث كل ساعة",
 all: "الكل", c_eng: "إنجلترا", c_esp: "إسبانيا", c_ita: "إيطاليا", c_ger: "ألمانيا", c_fra: "فرنسا", c_eur: "أوروبا", c_wld: "العالم",
 lg_eng: "الدوري الإنجليزي الممتاز", lg_esp: "الدوري الإسباني", lg_ita: "الدوري الإيطالي", lg_ger: "الدوري الألماني", lg_fra: "الدوري الفرنسي", lg_eur: "دوري الأبطال والاتحاد الأوروبي", lg_wld: "فيفا والمنتخبات",
 h_hl: "أحدث الملخصات", h_news: "آخر أخبار كرة القدم", h_art: "مقالات كرة القدم", see_art: "كل المقالات ←",
 more_hl: "عرض المزيد من الملخصات", more_news: "عرض المزيد من الأخبار", none: "لا يوجد شيء لهذا الدوري حاليًا – عد قريبًا.",
 qb_t: "ما مدى معرفتك بكرة القدم؟", qb_p: "العب اختبارنا حسب البلد والدوري – وتعلّم معلومة ممتعة مع كل إجابة.", qb_btn: "ابدأ الاختبار",
 updated: "آخر تحديث", foot: "تُعرض الفيديوهات على قنوات يوتيوب الرسمية لكل دوري. عناوين الأخبار مرتبطة بالناشرين الأصليين (BBC Sport وThe Guardian وESPN). جميع الحقوق محفوظة لأصحابها.",
 about: "من نحن", contact: "اتصل بنا", privacy: "الخصوصية", ago_m: "منذ {n} دقيقة", ago_h: "منذ {n} ساعة", ago_d: "منذ {n} يوم",
 art_note: "", qz_title: "🧠 اختبار كرة القدم", qz_intro: "اختر بلدًا أو دوريًا، وأجب عن 10 أسئلة، وتعلّم معلومة ممتعة مع كل إجابة.",
 qz_q: "السؤال {i} من {n}", qz_score: "النقاط", qz_next: "السؤال التالي ←", qz_see: "اعرض نتيجتي", qz_ok: "إجابة صحيحة!", qz_no: "ليس تمامًا. الإجابة الصحيحة هي",
 qz_your: "نتيجتك", qz_m1: "ممتاز! أنت عبقري كرة القدم 🏆", qz_m2: "عمل رائع – أنت تعرف كرة القدم جيدًا! ⚽", qz_m3: "ليس سيئًا! العب مجددًا لتتعلم المزيد 💪",
 qz_m4: "واصل المشاهدة والقراءة – ستنجح! 📚", qz_again: "العب مجددًا", qz_share: "شارك على فيسبوك",
 qz_more: "هل تريد معرفة المزيد؟ اقرأ <a href='articles/index.html'>مقالاتنا عن كرة القدم</a> أو شاهد <a href='index.html#highlights'>أحدث الملخصات</a>."},
fr: {m_table: "Classement", m_all_tables: "Voir tous les classements →", m_related: "Résumés et actus liés", m_all: "Tous les matchs", m_kick: "Coup d'envoi", m_venue: "Stade", m_watch: "Où regarder à la TV", m_h1: "Matchs de foot : scores en direct, horaires et chaînes TV", m_intro: "Tous les grands matchs de Premier League, Liga, Serie A, Bundesliga, Ligue 1, Ligue des champions et Ligue Europa.", m_upcoming: "À venir et en direct", m_recent: "Derniers résultats",
 yt_watch: "Regarder sur YouTube", my_teams: "Mes équipes", pick_teams: "Choisissez vos équipes préférées", done: "Terminé", yt_fallback: "La vidéo ne marche pas ? Regardez-la sur YouTube", no_my: "Rien pour vos équipes pour le moment. Touchez ⭐ Mes équipes pour les changer.", nav_tables: "Classements", h_tables: "Classements et meilleurs buteurs", tables_intro: "Classements, meilleurs buteurs et passeurs des plus grands championnats – mis à jour chaque heure.", t_team: "Équipe", t_p: "J", t_w: "G", t_d: "N", t_l: "P", t_gd: "Diff", t_pts: "Pts", t_player: "Joueur", t_scorers: "Meilleurs buteurs", t_assists: "Meilleurs passeurs", t_goals: "Buts", t_ast: "Passes D.",
 nav_live: "Direct", watch: "Suivi en direct", lv_title: "🔴 Matchs en direct", lv_intro: "Suivez les grands matchs en direct en version cartoon – score, minute, buts, cartons et stats mis à jour toutes les 30 secondes.", lv_none: "Aucun grand match en ce moment ni dans les prochaines 24 heures.", lv_sched: "Voir le programme des matchs", lv_ft: "Fin", lv_kick: "Coup d'envoi à {time}", lv_stats: "Statistiques", lv_events: "Moments clés", lv_src: "Mise à jour automatique toutes les 30 secondes. Vue cartoon basée sur les données du match en direct – pas de vraies images.", lv_goal: "BUT !", lv_wait: "Le match n'a pas encore commencé.", lv_noev: "Pas encore de moment fort.", st_pos: "Possession", st_shots: "Tirs", st_target: "Cadrés", st_corners: "Corners", st_fouls: "Fautes", st_yellow: "Cartons jaunes", ev_goal: "BUT pour {team} ! {p} marque.", ev_goal_a: "BUT pour {team} ! {p} marque sur une passe de {a}.", ev_pen: "But sur penalty pour {team} ! {p} transforme.", ev_og: "But contre son camp de {p}.", ev_red: "Carton rouge ! {p} ({team}) est expulsé.", ev_yellow: "Carton jaune pour {p} ({team}).", ev_sub: "Changement pour {team} : {p}.", ev_ko: "Coup d'envoi ! Le match a commencé.", ev_ht: "Mi-temps.", ev_2h: "La seconde période a commencé.", ev_ft: "Fin du match !",
 live: "EN DIRECT", nav_fix: "Matchs", h_fix: "Prochains matchs & chaînes TV", fix_note: "Les horaires sont affichés à votre heure locale. Les chaînes peuvent changer – vérifiez votre programme TV local.", more_fix: "Plus de matchs", tv_mena: "Monde arabe & Afrique du Nord", tv_usa: "États-Unis", tv_check: "Vérifiez votre programme TV local", no_fix: "Aucun match prévu dans les prochains jours.",
 nav_hl: "Résumés", nav_news: "Actus", nav_art: "Articles", nav_quiz: "Quiz", nav_fb: "Facebook", nav_about: "À propos",
 tagline: "Résumés et actus des plus grands championnats du monde · mis à jour chaque heure",
 all: "Tous", c_eng: "Angleterre", c_esp: "Espagne", c_ita: "Italie", c_ger: "Allemagne", c_fra: "France", c_eur: "Europe", c_wld: "Monde",
 lg_eur: "Ligue des champions & UEFA", lg_wld: "FIFA & sélections",
 h_hl: "Derniers résumés", h_news: "Dernières actus foot", h_art: "Articles foot", see_art: "Tous les articles →",
 more_hl: "Plus de résumés", more_news: "Plus d'actus", none: "Rien pour ce championnat pour le moment – revenez bientôt.",
 qb_t: "Connaissez-vous vraiment le football ?", qb_p: "Jouez à notre quiz par pays et championnat – une anecdote à chaque réponse.", qb_btn: "Jouer au quiz",
 updated: "Mis à jour", foot: "Les vidéos sont lues sur les chaînes YouTube officielles de chaque championnat. Les titres renvoient aux éditeurs d'origine (BBC Sport, The Guardian, ESPN). Tous les droits appartiennent à leurs propriétaires.",
 about: "À propos", contact: "Contact", privacy: "Confidentialité", ago_m: "il y a {n} min", ago_h: "il y a {n} h", ago_d: "il y a {n} j",
 art_note: "", qz_title: "🧠 Quiz football", qz_intro: "Choisissez un pays ou un championnat, répondez à 10 questions et découvrez une anecdote à chaque réponse.",
 qz_q: "Question {i} sur {n}", qz_score: "Score", qz_next: "Question suivante →", qz_see: "Voir mon score", qz_ok: "Bonne réponse !", qz_no: "Pas tout à fait. La réponse est",
 qz_your: "Votre score", qz_m1: "Parfait ! Vous êtes un génie du football 🏆", qz_m2: "Bravo – vous connaissez vraiment le football ! ⚽", qz_m3: "Pas mal ! Rejouez pour en apprendre plus 💪",
 qz_m4: "Continuez à regarder et à lire – vous y arriverez ! 📚", qz_again: "Rejouer", qz_share: "Partager sur Facebook",
 qz_more: "Envie d'en savoir plus ? Lisez nos <a href='articles/index.html'>articles foot</a> ou regardez les <a href='index.html#highlights'>derniers résumés</a>."},
es: {m_table: "Clasificación", m_all_tables: "Ver todas las clasificaciones →", m_related: "Resúmenes y noticias relacionadas", m_all: "Todos los partidos", m_kick: "Hora de inicio", m_venue: "Estadio", m_watch: "Dónde verlo por TV", m_h1: "Partidos de fútbol: resultados en vivo, horarios y canales de TV", m_intro: "Todos los grandes partidos de la Premier League, LaLiga, Serie A, Bundesliga, Ligue 1, Champions League y Europa League.", m_upcoming: "Próximos y en vivo", m_recent: "Últimos resultados",
 yt_watch: "Ver en YouTube", my_teams: "Mis equipos", pick_teams: "Elige tus equipos favoritos", done: "Listo", yt_fallback: "¿No se reproduce? Míralo en YouTube", no_my: "Nada de tus equipos por ahora. Toca ⭐ Mis equipos para cambiarlos.", nav_tables: "Tablas", h_tables: "Clasificaciones y goleadores", tables_intro: "Clasificaciones, goleadores y asistentes de las grandes ligas – actualizado cada hora.", t_team: "Equipo", t_p: "PJ", t_w: "G", t_d: "E", t_l: "P", t_gd: "DG", t_pts: "Pts", t_player: "Jugador", t_scorers: "Máximos goleadores", t_assists: "Máximos asistentes", t_goals: "Goles", t_ast: "Asist.",
 nav_live: "En vivo", watch: "Seguimiento en vivo", lv_title: "🔴 Partidos en vivo", lv_intro: "Sigue los grandes partidos en vivo en versión dibujos – marcador, minuto, goles, tarjetas y estadísticas cada 30 segundos.", lv_none: "No hay grandes partidos ahora ni en las próximas 24 horas.", lv_sched: "Ver el calendario", lv_ft: "Final", lv_kick: "Comienza a las {time}", lv_stats: "Estadísticas", lv_events: "Momentos clave", lv_src: "Se actualiza solo cada 30 segundos. Vista en dibujos basada en datos del partido en vivo – no son imágenes reales.", lv_goal: "¡GOL!", lv_wait: "El partido aún no ha empezado.", lv_noev: "Todavía no hay momentos destacados.", st_pos: "Posesión", st_shots: "Tiros", st_target: "A puerta", st_corners: "Córners", st_fouls: "Faltas", st_yellow: "Amarillas", ev_goal: "¡GOL de {team}! Marca {p}.", ev_goal_a: "¡GOL de {team}! Marca {p} con asistencia de {a}.", ev_pen: "¡Gol de penalti de {team}! {p} no falla.", ev_og: "Gol en propia puerta de {p}.", ev_red: "¡Roja! {p} ({team}) es expulsado.", ev_yellow: "Tarjeta amarilla para {p} ({team}).", ev_sub: "Cambio en {team}: {p}.", ev_ko: "¡Arranca el partido!", ev_ht: "Descanso.", ev_2h: "Comienza la segunda parte.", ev_ft: "¡Final del partido!",
 live: "EN VIVO", nav_fix: "Partidos", h_fix: "Próximos partidos y canales de TV", fix_note: "Los horarios se muestran en tu hora local. Los canales pueden cambiar – consulta tu programación local.", more_fix: "Ver más partidos", tv_mena: "Mundo árabe y norte de África", tv_usa: "EE. UU.", tv_check: "Consulta tu programación local", no_fix: "No hay partidos programados en los próximos días.",
 nav_hl: "Resúmenes", nav_news: "Noticias", nav_art: "Artículos", nav_quiz: "Quiz", nav_fb: "Facebook", nav_about: "Quiénes somos",
 tagline: "Resúmenes y noticias de las mayores ligas del mundo · actualizado cada hora",
 all: "Todos", c_eng: "Inglaterra", c_esp: "España", c_ita: "Italia", c_ger: "Alemania", c_fra: "Francia", c_eur: "Europa", c_wld: "Mundo",
 lg_eur: "Champions League y UEFA", lg_wld: "FIFA y selecciones",
 h_hl: "Últimos resúmenes", h_news: "Últimas noticias de fútbol", h_art: "Artículos de fútbol", see_art: "Ver todos los artículos →",
 more_hl: "Ver más resúmenes", more_news: "Ver más noticias", none: "Nada de esta liga por ahora – vuelve pronto.",
 qb_t: "¿Cuánto sabes de fútbol?", qb_p: "Juega a nuestro quiz por país y liga – aprende un dato curioso con cada respuesta.", qb_btn: "Jugar al quiz",
 updated: "Actualizado", foot: "Los vídeos se reproducen en los canales oficiales de YouTube de cada liga. Los titulares enlazan a los medios originales (BBC Sport, The Guardian, ESPN). Todos los derechos pertenecen a sus dueños.",
 about: "Quiénes somos", contact: "Contacto", privacy: "Privacidad", ago_m: "hace {n} min", ago_h: "hace {n} h", ago_d: "hace {n} d",
 art_note: "", qz_title: "🧠 Quiz de fútbol", qz_intro: "Elige un país o una liga, responde 10 preguntas y aprende un dato curioso con cada respuesta.",
 qz_q: "Pregunta {i} de {n}", qz_score: "Puntos", qz_next: "Siguiente pregunta →", qz_see: "Ver mi resultado", qz_ok: "¡Correcto!", qz_no: "Casi. La respuesta es",
 qz_your: "Tu resultado", qz_m1: "¡Perfecto! Eres un genio del fútbol 🏆", qz_m2: "¡Muy bien, sabes mucho de fútbol! ⚽", qz_m3: "¡Nada mal! Juega otra vez para aprender más 💪",
 qz_m4: "Sigue viendo y leyendo – ¡lo conseguirás! 📚", qz_again: "Jugar otra vez", qz_share: "Compartir en Facebook",
 qz_more: "¿Quieres saber más? Lee nuestros <a href='articles/index.html'>artículos de fútbol</a> o mira los <a href='index.html#highlights'>últimos resúmenes</a>."},
pt: {m_table: "Classificação", m_all_tables: "Ver todas as classificações →", m_related: "Melhores momentos e notícias relacionados", m_all: "Todos os jogos", m_kick: "Início", m_venue: "Estádio", m_watch: "Onde assistir na TV", m_h1: "Jogos de futebol: placares ao vivo, horários e canais de TV", m_intro: "Todos os grandes jogos da Premier League, LaLiga, Serie A, Bundesliga, Ligue 1, Champions League e Europa League.", m_upcoming: "Próximos e ao vivo", m_recent: "Últimos resultados",
 yt_watch: "Assistir no YouTube", my_teams: "Meus times", pick_teams: "Escolha seus times favoritos", done: "Pronto", yt_fallback: "O vídeo não abre? Assista no YouTube", no_my: "Nada dos seus times agora. Toque em ⭐ Meus times para mudar.", nav_tables: "Tabelas", h_tables: "Classificação e artilheiros", tables_intro: "Classificação, artilheiros e assistências das maiores ligas – atualizado a cada hora.", t_team: "Time", t_p: "J", t_w: "V", t_d: "E", t_l: "D", t_gd: "SG", t_pts: "Pts", t_player: "Jogador", t_scorers: "Artilheiros", t_assists: "Assistências", t_goals: "Gols", t_ast: "Assist.",
 nav_live: "Ao vivo", watch: "Acompanhar ao vivo", lv_title: "🔴 Jogos ao vivo", lv_intro: "Acompanhe os grandes jogos ao vivo em versão desenho – placar, minuto, gols, cartões e estatísticas a cada 30 segundos.", lv_none: "Nenhum grande jogo agora nem nas próximas 24 horas.", lv_sched: "Ver a programação", lv_ft: "Fim", lv_kick: "Começa às {time}", lv_stats: "Estatísticas", lv_events: "Momentos importantes", lv_src: "Atualiza sozinho a cada 30 segundos. Visual em desenho baseado em dados do jogo ao vivo – não são imagens reais.", lv_goal: "GOL!", lv_wait: "O jogo ainda não começou.", lv_noev: "Ainda sem lances importantes.", st_pos: "Posse de bola", st_shots: "Finalizações", st_target: "No alvo", st_corners: "Escanteios", st_fouls: "Faltas", st_yellow: "Amarelos", ev_goal: "GOL do {team}! {p} marca.", ev_goal_a: "GOL do {team}! {p} marca, com assistência de {a}.", ev_pen: "Gol de pênalti do {team}! {p} converte.", ev_og: "Gol contra de {p}.", ev_red: "Cartão vermelho! {p} ({team}) é expulso.", ev_yellow: "Cartão amarelo para {p} ({team}).", ev_sub: "Substituição no {team}: {p}.", ev_ko: "Bola rolando! O jogo começou.", ev_ht: "Intervalo.", ev_2h: "Começa o segundo tempo.", ev_ft: "Fim de jogo!",
 live: "AO VIVO", nav_fix: "Jogos", h_fix: "Próximos jogos e canais de TV", fix_note: "Os horários aparecem no seu fuso local. Os canais podem mudar – confira a programação local.", more_fix: "Ver mais jogos", tv_mena: "Mundo árabe e Norte da África", tv_usa: "EUA", tv_check: "Confira a programação local", no_fix: "Nenhum jogo marcado para os próximos dias.",
 nav_hl: "Melhores momentos", nav_news: "Notícias", nav_art: "Artigos", nav_quiz: "Quiz", nav_fb: "Facebook", nav_about: "Sobre",
 tagline: "Melhores momentos e notícias das maiores ligas do mundo · atualizado a cada hora",
 all: "Todos", c_eng: "Inglaterra", c_esp: "Espanha", c_ita: "Itália", c_ger: "Alemanha", c_fra: "França", c_eur: "Europa", c_wld: "Mundo",
 lg_eur: "Champions League e UEFA", lg_wld: "FIFA e seleções",
 h_hl: "Últimos melhores momentos", h_news: "Últimas notícias de futebol", h_art: "Artigos de futebol", see_art: "Ver todos os artigos →",
 more_hl: "Ver mais vídeos", more_news: "Ver mais notícias", none: "Nada desta liga por enquanto – volte em breve.",
 qb_t: "Quanto você sabe de futebol?", qb_p: "Jogue nosso quiz por país e liga – aprenda uma curiosidade a cada resposta.", qb_btn: "Jogar o quiz",
 updated: "Atualizado", foot: "Os vídeos são reproduzidos nos canais oficiais do YouTube de cada liga. As manchetes levam aos veículos originais (BBC Sport, The Guardian, ESPN). Todos os direitos pertencem aos seus donos.",
 about: "Sobre", contact: "Contato", privacy: "Privacidade", ago_m: "há {n} min", ago_h: "há {n} h", ago_d: "há {n} d",
 art_note: "", qz_title: "🧠 Quiz de futebol", qz_intro: "Escolha um país ou uma liga, responda 10 perguntas e aprenda uma curiosidade a cada resposta.",
 qz_q: "Pergunta {i} de {n}", qz_score: "Pontos", qz_next: "Próxima pergunta →", qz_see: "Ver meu resultado", qz_ok: "Correto!", qz_no: "Quase. A resposta é",
 qz_your: "Seu resultado", qz_m1: "Perfeito! Você é um gênio do futebol 🏆", qz_m2: "Muito bem – você entende de futebol! ⚽", qz_m3: "Nada mal! Jogue de novo para aprender mais 💪",
 qz_m4: "Continue assistindo e lendo – você chega lá! 📚", qz_again: "Jogar de novo", qz_share: "Compartilhar no Facebook",
 qz_more: "Quer saber mais? Leia nossos <a href='articles/index.html'>artigos de futebol</a> ou assista aos <a href='index.html#highlights'>últimos melhores momentos</a>."},
de: {m_table: "Tabelle", m_all_tables: "Alle Tabellen ansehen →", m_related: "Passende Highlights & News", m_all: "Alle Spiele", m_kick: "Anstoß", m_venue: "Stadion", m_watch: "Wo läuft das Spiel im TV?", m_h1: "Fußballspiele: Live-Ergebnisse, Anstoßzeiten & TV-Sender", m_intro: "Alle großen Spiele aus Premier League, LaLiga, Serie A, Bundesliga, Ligue 1, Champions League und Europa League.", m_upcoming: "Demnächst & live", m_recent: "Letzte Ergebnisse",
 yt_watch: "Auf YouTube ansehen", my_teams: "Meine Teams", pick_teams: "Wähle deine Lieblingsteams", done: "Fertig", yt_fallback: "Video startet nicht? Auf YouTube ansehen", no_my: "Gerade nichts zu deinen Teams. Tippe erneut auf ⭐ Meine Teams, um sie zu ändern.", nav_tables: "Tabellen", h_tables: "Tabellen & Torjäger", tables_intro: "Tabellen, Torjäger und Vorlagengeber der größten Ligen – stündlich aktualisiert.", t_team: "Team", t_p: "Sp", t_w: "S", t_d: "U", t_l: "N", t_gd: "TD", t_pts: "Pkt", t_player: "Spieler", t_scorers: "Torjäger", t_assists: "Vorlagengeber", t_goals: "Tore", t_ast: "Vorlagen",
 nav_live: "Live", watch: "Live-Ticker", lv_title: "🔴 Live-Spiele", lv_intro: "Verfolge die großen Spiele live als Cartoon – Ergebnis, Minute, Tore, Karten und Statistiken alle 30 Sekunden aktualisiert.", lv_none: "Gerade und in den nächsten 24 Stunden keine großen Spiele.", lv_sched: "Zum Spielplan", lv_ft: "Ende", lv_kick: "Anstoß um {time}", lv_stats: "Statistiken", lv_events: "Wichtige Momente", lv_src: "Aktualisiert sich alle 30 Sekunden. Cartoon-Ansicht nach Live-Spieldaten – keine echten Spielszenen.", lv_goal: "TOR!", lv_wait: "Das Spiel hat noch nicht begonnen.", lv_noev: "Noch keine besonderen Momente.", st_pos: "Ballbesitz", st_shots: "Schüsse", st_target: "Aufs Tor", st_corners: "Ecken", st_fouls: "Fouls", st_yellow: "Gelbe Karten", ev_goal: "TOR für {team}! {p} trifft.", ev_goal_a: "TOR für {team}! {p} trifft nach Vorlage von {a}.", ev_pen: "Elfmetertor für {team}! {p} verwandelt.", ev_og: "Eigentor von {p}.", ev_red: "Rote Karte! {p} ({team}) fliegt vom Platz.", ev_yellow: "Gelbe Karte für {p} ({team}).", ev_sub: "Wechsel bei {team}: {p}.", ev_ko: "Anstoß! Das Spiel läuft.", ev_ht: "Halbzeit.", ev_2h: "Die zweite Halbzeit läuft.", ev_ft: "Abpfiff!",
 live: "LIVE", nav_fix: "Spiele", h_fix: "Nächste Spiele & TV-Sender", fix_note: "Die Zeiten werden in deiner Ortszeit angezeigt. TV-Sender können sich ändern – bitte prüfe dein lokales TV-Programm.", more_fix: "Mehr Spiele", tv_mena: "Arabische Welt & Nordafrika", tv_usa: "USA", tv_check: "Bitte lokales TV-Programm prüfen", no_fix: "In den nächsten Tagen sind keine Spiele angesetzt.",
 nav_hl: "Highlights", nav_news: "News", nav_art: "Artikel", nav_quiz: "Quiz", nav_fb: "Facebook", nav_about: "Über uns",
 tagline: "Highlights und News aus den größten Ligen der Welt · stündlich aktualisiert",
 all: "Alle", c_eng: "England", c_esp: "Spanien", c_ita: "Italien", c_ger: "Deutschland", c_fra: "Frankreich", c_eur: "Europa", c_wld: "Welt",
 lg_eur: "Champions League & UEFA", lg_wld: "FIFA & Nationalteams",
 h_hl: "Neueste Highlights", h_news: "Neueste Fußball-News", h_art: "Fußball-Artikel", see_art: "Alle Artikel →",
 more_hl: "Mehr Highlights", more_news: "Mehr News", none: "Gerade nichts zu dieser Liga – schau bald wieder vorbei.",
 qb_t: "Wie gut kennst du dich im Fußball aus?", qb_p: "Spiel unser Quiz nach Land und Liga – mit einem spannenden Fakt zu jeder Antwort.", qb_btn: "Quiz spielen",
 updated: "Aktualisiert", foot: "Die Videos laufen auf den offiziellen YouTube-Kanälen der Ligen. Die Schlagzeilen verlinken auf die ursprünglichen Medien (BBC Sport, The Guardian, ESPN). Alle Rechte liegen bei den Eigentümern.",
 about: "Über uns", contact: "Kontakt", privacy: "Datenschutz", ago_m: "vor {n} Min.", ago_h: "vor {n} Std.", ago_d: "vor {n} T.",
 art_note: "", qz_title: "🧠 Fußball-Quiz", qz_intro: "Wähle ein Land oder eine Liga, beantworte 10 Fragen und lerne zu jeder Antwort einen spannenden Fakt.",
 qz_q: "Frage {i} von {n}", qz_score: "Punkte", qz_next: "Nächste Frage →", qz_see: "Mein Ergebnis", qz_ok: "Richtig!", qz_no: "Nicht ganz. Die Antwort ist",
 qz_your: "Dein Ergebnis", qz_m1: "Perfekt! Du bist ein Fußball-Genie 🏆", qz_m2: "Super – du kennst dich richtig gut aus! ⚽", qz_m3: "Nicht schlecht! Spiel nochmal und lerne mehr 💪",
 qz_m4: "Weiter schauen und lesen – du schaffst das! 📚", qz_again: "Nochmal spielen", qz_share: "Auf Facebook teilen",
 qz_more: "Mehr erfahren? Lies unsere <a href='articles/index.html'>Fußball-Artikel</a> oder schau die <a href='index.html#highlights'>neuesten Highlights</a>."},
it: {m_table: "Classifica", m_all_tables: "Vedi tutte le classifiche →", m_related: "Highlights e notizie correlate", m_all: "Tutte le partite", m_kick: "Calcio d'inizio", m_venue: "Stadio", m_watch: "Dove vederla in TV", m_h1: "Partite di calcio: risultati live, orari e canali TV", m_intro: "Tutte le grandi partite di Premier League, LaLiga, Serie A, Bundesliga, Ligue 1, Champions League ed Europa League.", m_upcoming: "In arrivo e live", m_recent: "Ultimi risultati",
 yt_watch: "Guarda su YouTube", my_teams: "Le mie squadre", pick_teams: "Scegli le tue squadre preferite", done: "Fatto", yt_fallback: "Il video non parte? Guardalo su YouTube", no_my: "Niente per le tue squadre ora. Tocca ⭐ Le mie squadre per cambiarle.", nav_tables: "Classifiche", h_tables: "Classifiche e capocannonieri", tables_intro: "Classifiche, capocannonieri e assistman dei grandi campionati – aggiornato ogni ora.", t_team: "Squadra", t_p: "G", t_w: "V", t_d: "N", t_l: "P", t_gd: "DR", t_pts: "Pt", t_player: "Giocatore", t_scorers: "Capocannonieri", t_assists: "Assistman", t_goals: "Gol", t_ast: "Assist",
 nav_live: "Live", watch: "Segui live", lv_title: "🔴 Partite live", lv_intro: "Segui le grandi partite live in versione cartoon – risultato, minuto, gol, cartellini e statistiche ogni 30 secondi.", lv_none: "Nessuna grande partita ora o nelle prossime 24 ore.", lv_sched: "Vedi il calendario", lv_ft: "Finale", lv_kick: "Calcio d'inizio alle {time}", lv_stats: "Statistiche", lv_events: "Momenti chiave", lv_src: "Si aggiorna da solo ogni 30 secondi. Vista cartoon basata sui dati live della partita – non sono immagini reali.", lv_goal: "GOL!", lv_wait: "La partita non è ancora iniziata.", lv_noev: "Ancora nessun momento importante.", st_pos: "Possesso", st_shots: "Tiri", st_target: "In porta", st_corners: "Calci d'angolo", st_fouls: "Falli", st_yellow: "Gialli", ev_goal: "GOL del {team}! Segna {p}.", ev_goal_a: "GOL del {team}! Segna {p} su assist di {a}.", ev_pen: "Gol su rigore del {team}! {p} trasforma.", ev_og: "Autogol di {p}.", ev_red: "Cartellino rosso! {p} ({team}) è espulso.", ev_yellow: "Cartellino giallo per {p} ({team}).", ev_sub: "Cambio per il {team}: {p}.", ev_ko: "Calcio d'inizio! Si parte.", ev_ht: "Intervallo.", ev_2h: "Inizia il secondo tempo.", ev_ft: "Fine partita!",
 live: "LIVE", nav_fix: "Partite", h_fix: "Prossime partite e canali TV", fix_note: "Gli orari sono nel tuo fuso orario. I canali possono cambiare – controlla la guida TV locale.", more_fix: "Altre partite", tv_mena: "Mondo arabo e Nord Africa", tv_usa: "USA", tv_check: "Controlla la guida TV locale", no_fix: "Nessuna partita in programma nei prossimi giorni.",
 nav_hl: "Highlights", nav_news: "Notizie", nav_art: "Articoli", nav_quiz: "Quiz", nav_fb: "Facebook", nav_about: "Chi siamo",
 tagline: "Highlights e notizie dai più grandi campionati del mondo · aggiornato ogni ora",
 all: "Tutti", c_eng: "Inghilterra", c_esp: "Spagna", c_ita: "Italia", c_ger: "Germania", c_fra: "Francia", c_eur: "Europa", c_wld: "Mondo",
 lg_eur: "Champions League e UEFA", lg_wld: "FIFA e nazionali",
 h_hl: "Ultimi highlights", h_news: "Ultime notizie di calcio", h_art: "Articoli di calcio", see_art: "Tutti gli articoli →",
 more_hl: "Altri highlights", more_news: "Altre notizie", none: "Niente per questo campionato al momento – torna presto.",
 qb_t: "Quanto ne sai di calcio?", qb_p: "Gioca al nostro quiz per paese e campionato – scopri una curiosità a ogni risposta.", qb_btn: "Gioca al quiz",
 updated: "Aggiornato", foot: "I video si guardano sui canali YouTube ufficiali di ogni campionato. I titoli rimandano alle testate originali (BBC Sport, The Guardian, ESPN). Tutti i diritti appartengono ai rispettivi proprietari.",
 about: "Chi siamo", contact: "Contatti", privacy: "Privacy", ago_m: "{n} min fa", ago_h: "{n} h fa", ago_d: "{n} g fa",
 art_note: "", qz_title: "🧠 Quiz di calcio", qz_intro: "Scegli un paese o un campionato, rispondi a 10 domande e scopri una curiosità a ogni risposta.",
 qz_q: "Domanda {i} di {n}", qz_score: "Punti", qz_next: "Domanda successiva →", qz_see: "Vedi il mio punteggio", qz_ok: "Esatto!", qz_no: "Non proprio. La risposta è",
 qz_your: "Il tuo punteggio", qz_m1: "Perfetto! Sei un genio del calcio 🏆", qz_m2: "Ottimo – di calcio ne sai davvero! ⚽", qz_m3: "Non male! Gioca ancora per imparare di più 💪",
 qz_m4: "Continua a guardare e leggere – ce la farai! 📚", qz_again: "Gioca ancora", qz_share: "Condividi su Facebook",
 qz_more: "Vuoi saperne di più? Leggi i nostri <a href='articles/index.html'>articoli di calcio</a> o guarda gli <a href='index.html#highlights'>ultimi highlights</a>."}
};

function pick() {
  var s = null;
  try { s = localStorage.getItem("fa_lang"); } catch (e) {}
  if (s && T[s]) return s;
  var n = (navigator.language || "en").slice(0, 2).toLowerCase();
  return T[n] ? n : "en";
}
var FA = window.FA = {lang: pick(), langs: LANGS,
  t: function (k, v) {
    var s = (T[FA.lang] && T[FA.lang][k]); if (s == null) s = T.en[k]; if (s == null) s = k;
    for (var x in (v || {})) s = s.split("{" + x + "}").join(v[x]);
    return s;
  },
  tl: function (l, k, v) {  // translate into a chosen language (used by the live commentator)
    var s = (T[l] && T[l][k]); if (s == null) s = T.en[k]; if (s == null) s = k;
    for (var x in (v || {})) s = s.split("{" + x + "}").join(v[x]);
    return s;
  },
  ago: function (t) {
    var s = Date.now() / 1000 - t;
    if (s < 3600) return FA.t("ago_m", {n: Math.max(1, Math.floor(s / 60))});
    if (s < 86400) return FA.t("ago_h", {n: Math.floor(s / 3600)});
    return FA.t("ago_d", {n: Math.floor(s / 86400)});
  },
  apply: function () {
    var root = document.documentElement;
    root.lang = FA.lang; root.dir = FA.lang === "ar" ? "rtl" : "ltr";
    document.querySelectorAll("[data-i18n]").forEach(function (e) { e.textContent = FA.t(e.dataset.i18n); });
    document.querySelectorAll("[data-i18n-html]").forEach(function (e) { e.innerHTML = FA.t(e.dataset.i18nHtml); });
    document.querySelectorAll("[data-i18n-note]").forEach(function (e) { var s = FA.t("art_note"); e.textContent = s; e.style.display = s ? "" : "none"; });
    document.querySelectorAll(".ago[data-t]").forEach(function (e) { e.textContent = FA.ago(+e.dataset.t); });
    var loc = FA.lang === "ar" ? "ar-MA" : FA.lang;
    document.querySelectorAll(".ftime[data-k]").forEach(function (e) {
      var d = new Date(+e.dataset.k * 1000);
      try { e.textContent = d.toLocaleDateString(loc, {weekday: "long", day: "numeric", month: "long"}) + " · " + d.toLocaleTimeString(loc, {hour: "2-digit", minute: "2-digit"}); } catch (x) {}
    });
    document.querySelectorAll(".langpick").forEach(function (s) { s.value = FA.lang; });
  },
  extend: function (more) {  // extra words from fa.js and the home page
    for (var l in more) { T[l] = T[l] || {}; for (var k in more[l]) T[l][k] = more[l][k]; }
  },
  set: function (l) {
    FA.lang = T[l] ? l : "en";
    try { localStorage.setItem("fa_lang", FA.lang); } catch (e) {}
    FA.apply();
    document.dispatchEvent(new Event("fa:lang"));
  }
};
document.querySelectorAll(".langpick").forEach(function (s) {
  s.innerHTML = LANGS.map(function (l) { return '<option value="' + l[0] + '">' + l[1] + "</option>"; }).join("");
  s.onchange = function () { FA.set(s.value); };
});
FA.apply();
})();
