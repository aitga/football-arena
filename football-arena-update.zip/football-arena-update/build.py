"""Builds the Football Arena website (index.html) from live football news feeds
and the leagues' official YouTube highlight channels. Runs every hour on GitHub."""
import datetime
import email.utils
import html
import json
import os
import re
import xml.etree.ElementTree as ET

import requests

UA = {"User-Agent": "FootballArenaBot/1.0 (+https://github.com)"}

NEWS_FEEDS = [
    ("BBC Sport", "https://feeds.bbci.co.uk/sport/football/rss.xml"),
    ("The Guardian", "https://www.theguardian.com/football/rss"),
    ("ESPN", "https://www.espn.com/espn/rss/soccer/news"),
]
# official league / competition YouTube channels (by @handle)
HIGHLIGHT_CHANNELS = [  # official league / competition YouTube channels (channel IDs)
    ("Premier League", "UCG5qGWdu8nIRZqJ_GgDwQ-w"),
    ("LaLiga", "UCTv-XvfzLX3i4IGWAm4sbmA"),
    ("UEFA", "UCyGa1YEx9ST66rYrJTGIKOw"),
    ("Serie A", "UCBJeMCIeLQos7wacox4hmLQ"),
    ("Bundesliga", "UC6UL29enLNe4mqwTfAyeNuw"),
    ("FIFA", "UCpcTrCXblq78GZrTUTLWeBw"),
    ("Ligue 1", "@Ligue1"),  # handle: looked up to its channel ID automatically
    ("beIN SPORTS", "@beINSPORTS"),  # Arabic commentary (Middle East & North Africa)
]
AR_CHANNELS = {"beIN SPORTS"}  # channels whose videos have Arabic commentary (only their highlight videos are used)
AR_LEAGUE = [("eng", r"الإنجليزي|الانجليزي|البريميرليغ"), ("esp", r"الإسباني|الاسباني|الليغا"), ("ita", r"الإيطالي|الايطالي"),
             ("ger", r"الألماني|الالماني|البوندسليغا"), ("fra", r"الفرنسي"), ("eur", r"أبطال أوروبا|ابطال اوروبا|الدوري الأوروبي|الدوري الاوروبي")]


def commentary_of(v):
    """'ar' for Arabic commentary, 'en' for the official league channels (English)."""
    return "ar" if v["channel"] in AR_CHANNELS or re.search("[\u0600-\u06FF]", v["title"]) else "en"


def league_of_video(v):
    if v["channel"] in CHANNEL_LEAGUE:
        return CHANNEL_LEAGUE[v["channel"]]
    for k, rx in AR_LEAGUE:
        if re.search(rx, v["title"]):
            return k
    return "wld"
NS = {"atom": "http://www.w3.org/2005/Atom", "media": "http://search.yahoo.com/mrss/",
      "yt": "http://www.youtube.com/xml/schemas/2015"}


def get(url):
    r = requests.get(url, headers=UA, timeout=30)
    r.raise_for_status()
    return r.content


def parse_date(text):
    """The publisher's own time (RSS pubDate / YouTube publishedAt). None if missing: we never use 'now',
    because that made every item say '1 min ago'."""
    text = (text or "").strip()
    if not text:
        return None
    try:
        d = email.utils.parsedate_to_datetime(text)
    except Exception:
        try:
            d = datetime.datetime.fromisoformat(text.replace("Z", "+00:00"))
        except Exception:
            return None
    if d.tzinfo is None:
        d = d.replace(tzinfo=datetime.timezone.utc)
    return d.astimezone(datetime.timezone.utc)


def clean(text, limit=220):
    text = re.sub(r"<[^>]+>", "", html.unescape(text or "")).strip()
    return text if len(text) <= limit else text[:limit].rsplit(" ", 1)[0] + "…"


def news():
    items = []
    for source, url in NEWS_FEEDS:
        try:
            root = ET.fromstring(get(url))
        except Exception as e:
            print("Feed failed:", source, e)
            continue
        for it in root.iter("item"):
            img = None
            for tag in ("media:thumbnail", "media:content"):
                el = it.find(tag, NS)
                if el is not None and el.get("url"):
                    img = el.get("url")
            enc = it.find("enclosure")
            if not img and enc is not None and "image" in (enc.get("type") or ""):
                img = enc.get("url")
            d = parse_date(it.findtext("pubDate") or it.findtext("{http://www.w3.org/2005/Atom}updated") or
                           it.findtext("{http://purl.org/dc/elements/1.1/}date") or "")
            if d is None:
                print("No publish time, skipped:", (it.findtext("title") or "")[:60])
                continue
            items.append({"source": source, "title": clean(it.findtext("title"), 160),
                          "link": (it.findtext("link") or "").strip(), "summary": clean(it.findtext("description")),
                          "date": d, "image": img})
    seen, out = set(), []
    for it in sorted(items, key=lambda x: x["date"], reverse=True):
        key = it["title"].lower()[:60]
        if it["link"] and key not in seen:
            seen.add(key)
            out.append(it)
    return out[:60]


def channel_id(handle):
    page = get(f"https://www.youtube.com/{handle}").decode("utf-8", "ignore")
    m = re.search(r'"(?:externalId|channelId)":"(UC[\w-]{22})"', page)
    return m.group(1) if m else None


def channel_videos_api(cid, key):
    """Official YouTube Data API (free key): latest uploads of a channel."""
    if not cid.startswith("UC"):
        ch = requests.get("https://www.googleapis.com/youtube/v3/channels", timeout=30,
                          params={"part": "id", "forHandle": cid, "key": key}).json()
        cid = ch["items"][0]["id"]
    r = requests.get("https://www.googleapis.com/youtube/v3/playlistItems", timeout=30, params={
        "part": "snippet", "playlistId": "UU" + cid[2:], "maxResults": 8, "key": key}).json()
    if "error" in r:
        raise RuntimeError(r["error"].get("message"))
    out = []
    for it in r.get("items", []):
        sn = it["snippet"]
        out.append({"id": sn["resourceId"]["videoId"], "title": sn["title"], "date": sn["publishedAt"]})
    return out


def highlights():
    vids = []
    key = os.environ.get("YT_API_KEY", "").strip()
    for name, handle in HIGHLIGHT_CHANNELS:
        if key:
            try:
                for v in channel_videos_api(handle, key):
                    if "shorts" not in v["title"].lower():
                        vids.append({"channel": name, "id": v["id"], "title": clean(v["title"], 120),
                                     "date": parse_date(v["date"])})
                continue
            except Exception as e:
                print("YouTube API failed:", name, e)
        try:
            cid = handle if handle.startswith("UC") else channel_id(handle)
            root = ET.fromstring(get(f"https://www.youtube.com/feeds/videos.xml?channel_id={cid}"))
        except Exception as e:
            print("Channel failed:", name, e)
            continue
        for en in root.findall("atom:entry", NS)[:8]:
            title = en.findtext("atom:title", "", NS)
            if "shorts" in title.lower():
                continue
            vids.append({"channel": name, "id": en.findtext("yt:videoId", "", NS), "title": clean(title, 120),
                         "date": parse_date(en.findtext("atom:published", "", NS))})
    vids = [v for v in vids if v["date"] is not None]
    if key and vids:  # ask YouTube which videos may be played on other sites (status.embeddable)
        try:
            ids = [v["id"] for v in vids]
            emb = {}
            for i in range(0, len(ids), 50):
                r = requests.get("https://www.googleapis.com/youtube/v3/videos", timeout=30,
                                 params={"part": "status", "id": ",".join(ids[i:i + 50]), "key": key}).json()
                for it in r.get("items", []):
                    emb[it["id"]] = it.get("status", {}).get("embeddable", True)
            for v in vids:
                v["embed"] = emb.get(v["id"], True)
        except Exception as ex:
            print("Embeddable check failed:", ex)
    hl = [v for v in vids if re.search(r"highlight|resumen|sintesi|goals?\b|résumé|ملخص|أهداف|اهداف", v["title"], re.I)]
    rest = [v for v in vids if v not in hl and v["channel"] not in AR_CHANNELS]  # Arabic channels: highlights only
    return sorted(hl, key=lambda v: v["date"], reverse=True)[:18] + sorted(rest, key=lambda v: v["date"], reverse=True)[:6]


def ago(d):
    s = (datetime.datetime.now(datetime.timezone.utc) - d).total_seconds()
    if s < 3600:
        return f"{max(1, int(s // 60))} min ago"
    if s < 86400:
        return f"{int(s // 3600)} h ago"
    return f"{int(s // 86400)} d ago"


# country / league groups used for the filter buttons
LEAGUES = [  # key, flag code (flagcdn), country, league, news keywords
    ("eng", "gb-eng", "England", "Premier League",
     r"premier league|arsenal|chelsea|liverpool|man(chester)? (city|utd|united)|tottenham|spurs|newcastle|aston villa|"
     r"everton|west ham|brighton|crystal palace|fulham|wolves|brentford|bournemouth|nottingham forest|leeds|burnley|sunderland|"
     r"fa cup|carabao|efl|championship|amorim|arteta|slot\b|guardiola|maresca|england"),
    ("esp", "es", "Spain", "LaLiga",
     r"la ?liga|real madrid|barcelona|barça|atletico|atlético|sevilla|villarreal|real sociedad|athletic (club|bilbao)|"
     r"betis|valencia|girona|osasuna|celta|mallorca|espanyol|getafe|rayo|alaves|alavés|copa del rey|ancelotti|flick|simeone|xabi alonso|spain"),
    ("ita", "it", "Italy", "Serie A",
     r"serie a|juventus|\binter\b|inter milan|ac milan|\bmilan\b|napoli|roma\b|lazio|atalanta|fiorentina|bologna|torino|"
     r"genoa|udinese|como\b|coppa italia|conte|allegri|italy|italian"),
    ("ger", "de", "Germany", "Bundesliga",
     r"bundesliga|bayern|dortmund|leverkusen|leipzig|frankfurt|stuttgart|wolfsburg|gladbach|freiburg|union berlin|"
     r"werder|hoffenheim|mainz|kompany|germany|german"),
    ("fra", "fr", "France", "Ligue 1",
     r"ligue 1|psg|paris saint|paris st|marseille|lyon|monaco|lille|nice\b|lens\b|rennes|nantes|france|french"),
    ("eur", "eu", "Europe", "Champions League & UEFA",
     r"champions league|europa league|conference league|uefa|euro 20\d\d"),
    ("wld", "", "World", "FIFA & International",
     r"world cup|fifa|international|africa cup|afcon|copa america|nations league|qualifier|morocco|brazil|argentina|usa\b|mexico"),
]
CHANNEL_LEAGUE = {"Premier League": "eng", "LaLiga": "esp", "Serie A": "ita", "Bundesliga": "ger",
                  "Ligue 1": "fra", "UEFA": "eur", "FIFA": "wld"}
SMALL = {"of", "the", "and", "in", "at", "vs", "v", "to", "de", "la", "el", "on", "for", "from", "with"}


FIXED = {"laliga": "LaLiga", "uefa": "UEFA", "fifa": "FIFA", "var": "VAR", "psg": "PSG", "mvp": "MVP",
         "#ucl": "#UCL", "ucl": "UCL", "goals!": "Goals!"}


def nice_title(t):
    """JUVENTUS-NAPOLI 2-0 | EXTENDED HIGHLIGHTS -> Juventus-Napoli 2-0 | Extended Highlights"""
    letters = [c for c in t if c.isalpha()]
    if not letters or sum(c.isupper() for c in letters) / len(letters) < 0.6:
        return t
    out = []
    for i, w in enumerate(t.split(" ")):
        lw = w.lower()
        if lw in FIXED:
            out.append(FIXED[lw])
        elif i and lw in SMALL:
            out.append(lw)
        elif len(w) <= 3 and w.isalpha():
            out.append(w)  # keep short codes: UCL, PSG, AC, FC
        else:
            out.append("-".join(p[:1].upper() + p[1:].lower() for p in w.split("-")))
    return " ".join(out)


def league_of_news(n):
    text = (n["title"] + " " + n["summary"]).lower()
    for key, *_rest, kw in LEAGUES:
        if re.search(kw, text):
            return key
    return "wld"


def flag(key):
    for k, code, country, *_ in LEAGUES:
        if k == key:
            return (f'<img class="flag" src="https://flagcdn.com/w40/{code}.png" alt="{country}" width="20" height="14">'
                    if code else '<span class="flag globe">🌍</span>')
    return ""



# ---------- upcoming matches (ESPN public scoreboard) ----------
FIX_LEAGUES = [("eng", "eng.1"), ("esp", "esp.1"), ("ita", "ita.1"), ("ger", "ger.1"), ("fra", "fra.1"),
               ("eur", "uefa.champions"), ("eur", "uefa.europa")]
# who shows each league in the Arab world / North Africa (checked Nov 2026; update if rights change)
MENA_TV = {"eng": "beIN SPORTS", "esp": "beIN SPORTS", "ger": "beIN SPORTS", "fra": "beIN SPORTS", "eur": "beIN SPORTS"}


def fixtures(days=7):
    out, seen = [], set()
    today = datetime.datetime.now(datetime.timezone.utc)
    for key, code in FIX_LEAGUES:
        for k in range(-1, days):  # yesterday too, so finished matches get their final score
            day = (today + datetime.timedelta(days=k)).strftime("%Y%m%d")
            try:
                data = json.loads(get(f"https://site.api.espn.com/apis/site/v2/sports/soccer/{code}/scoreboard?dates={day}"))
            except Exception as ex:
                print("Fixtures failed:", code, day, ex)
                continue
            for ev in data.get("events", []):
                st = ev.get("status", {}).get("type", {}).get("state")
                if st not in ("pre", "in", "post") or ev["id"] in seen:
                    continue
                seen.add(ev["id"])
                c = ev["competitions"][0]
                teams = {t.get("homeAway"): t for t in c.get("competitors", [])}
                h, a = teams.get("home", {}), teams.get("away", {})
                tv = []
                for b in c.get("broadcasts", []) or []:
                    tv += b.get("names", [])
                evs = []  # [kind, minute] for the spoiler-free thrill score: g = goal, r = red card
                for dt in c.get("details", []) or []:
                    m = re.match(r"(\d+)", str((dt.get("clock") or {}).get("displayValue", "")))
                    mn = int(m.group(1)) if m else 0
                    if dt.get("scoringPlay") and not dt.get("shootout"):
                        evs.append(["g", mn])
                    if dt.get("redCard"):
                        evs.append(["r", mn])
                out.append({"id": ev["id"], "code": code, "l": key, "comp": data.get("leagues", [{}])[0].get("name", ""), "date": ev["date"],
                            "ev": evs, "hlogo": h.get("team", {}).get("logo", ""), "alogo": a.get("team", {}).get("logo", ""),
                            "home": h.get("team", {}).get("displayName", "?"), "away": a.get("team", {}).get("displayName", "?"),
                            "hs": h.get("score", ""), "as": a.get("score", ""), "live": st == "in", "state": st,
                            "clock": ev.get("status", {}).get("displayClock", ""),
                            "venue": (c.get("venue") or {}).get("fullName", ""), "usa": sorted(set(tv))})
    out.sort(key=lambda f: f["date"])
    return out[:160]


def fixture_cards(fx, slugs=None):
    e = html.escape
    slugs = slugs or {}
    rows = []
    for f in fx:
        if f.get("state") == "post":
            continue
        d = parse_date(f["date"])
        if not f["live"] and d < datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(hours=3):
            continue
        mid = (f'<span class="sc"><b>{e(str(f["hs"]))}</b><b>–</b><b>{e(str(f["as"]))}</b></span>' if f["live"] else '<span class="vs">vs</span>')
        badge = f'<span class="live">● <span data-i18n="live">LIVE</span> {e(f["clock"])}</span>' if f["live"] else ""
        tv = ""
        if MENA_TV.get(f["l"]):
            tv += f'<div>📺 <span data-i18n="tv_mena">Arab world & North Africa</span>: <b>{e(MENA_TV[f["l"]])}</b></div>'
        if f["usa"]:
            tv += f'<div>📺 <span data-i18n="tv_usa">USA</span>: <b>{e(", ".join(f["usa"]))}</b></div>'
        if not tv:
            tv = '<div>📺 <span data-i18n="tv_check">Check your local TV listings</span></div>'
        comp = f'<span data-i18n="lg_{f["l"]}">{e(f["comp"])}</span>' if f["l"] != "eur" else e(f["comp"])
        rows.append(
            f'<div class="card fix" data-l="{f["l"]}" data-s="{e(plain(f["home"] + " " + f["away"]))}"><div class="ftop">{flag(f["l"])} {comp}{badge}</div>'
            f'<div class="ftime" data-k="{int(d.timestamp())}">{d.strftime("%a %d %b · %H:%M UTC")}</div>'
            + (f'<a class="teams" href="matches/{e(slugs[f["id"]])}.html">' if f.get("id") in slugs else '<div class="teams">')
            + f'<span>{e(f["home"])}</span>{mid}<span>{e(f["away"])}</span>' + ('</a>' if f.get("id") in slugs else '</div>')
            + f'<div class="tv">{tv}</div>' + (f'<div class="venue">🏟️ {e(f["venue"])}</div>' if f["venue"] else "")
            + (f'<a class="watch" href="live.html#{e(f["code"])}/{e(f["id"])}">🔴 <span data-i18n="watch">Live tracker</span></a>' if f.get("id") else "")
            + '</div>')
    return "\n".join(rows) or '<p class="empty" data-i18n="no_fix">No matches scheduled in the next few days.</p>'


def gsv_tags():
    """Search-engine ownership tags from seo.json, e.g. {"google": "abc...", "bing": "123..."}"""
    try:
        cfg = json.load(open("seo.json"))
    except Exception:
        return ""
    out = ""
    if cfg.get("google"):
        out += f'<meta name="google-site-verification" content="{html.escape(cfg["google"])}">'
    if cfg.get("bing"):
        out += f'<meta name="msvalidate.01" content="{html.escape(cfg["bing"])}">'
    return out


STATIC_PAGES = ["", "tables.html", "matches/index.html", "live.html", "quiz.html", "articles/index.html", "about.html", "contact.html", "privacy.html"]


def write_sitemap(match_pages):
    import glob
    now = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d")
    urls = [(p, now, "hourly" if p in ("", "tables.html", "matches/index.html") else "weekly") for p in STATIC_PAGES]
    urls += [(p, now, "monthly") for p in sorted(glob.glob("articles/*.html")) if not p.endswith("index.html")]
    urls += [(p, d.strftime("%Y-%m-%d"), "hourly") for p, d in match_pages]
    xml = ['<?xml version="1.0" encoding="UTF-8"?>', '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']
    for p, mod, freq in urls:
        xml.append(f"  <url><loc>https://www.footballarena.net/{html.escape(p)}</loc><lastmod>{mod}</lastmod><changefreq>{freq}</changefreq></url>")
    xml.append("</urlset>")
    open("sitemap.xml", "w").write("\n".join(xml) + "\n")
    open("robots.txt", "w").write("User-agent: *\nAllow: /\n\nSitemap: https://www.footballarena.net/sitemap.xml\n")
    return len(urls)


def plain(t):
    import unicodedata
    return "".join(ch for ch in unicodedata.normalize("NFD", (t or "").lower()) if unicodedata.category(ch) != "Mn")


def ago_span(d):
    return f'<span class="ago" data-t="{int(d.timestamp())}">{ago(d)}</span>'


def render(news_cards, cards, fx=(), teams=(), slugs=None):
    import sys
    import home
    return home.render(sys.modules[__name__], news_cards, cards, fx, teams, slugs)


def mark_neutral(cards):
    """Spoiler-free label for every highlight card: 'Home vs Away · League highlights'."""
    names = {k: league for k, _c, _country, league, _kw in LEAGUES}
    for c in cards:
        c["lg"] = league_of_video(c)
        c["neutral"] = enhance.neutral_title(c, names.get(c["lg"], "Football"))


def as_json(x):
    return dict(x, date=x["date"].isoformat())


if __name__ == "__main__":
    import enhance
    n, v = news(), highlights()
    try:
        fx = fixtures()
    except Exception as ex:
        print("Fixtures failed:", ex)
        fx = []
    try:
        old = json.load(open("latest.json"))
    except Exception:
        old = {}
    if not v and old.get("videos"):  # YouTube hiccup: keep the last good highlights
        v = [dict(x, date=datetime.datetime.fromisoformat(x["date"])) for x in old["videos"]]
    if not n and old.get("news_all"):
        n = [dict(x, date=datetime.datetime.fromisoformat(x["date"])) for x in old["news_all"]]
    if not fx and old.get("fixtures"):
        fx = old["fixtures"]
    v = enhance.football_only(v)
    n = enhance.football_only(n, extra="summary")
    import tables
    try:
        tb = tables.fetch(get)
    except Exception as ex:
        print("Tables failed:", ex)
        tb = {"leagues": [], "teams": []}
    if not any(lg["rows"] for lg in tb["leagues"]) and old.get("tables"):
        tb = old["tables"]
    for t in tb["teams"]:  # refresh club name keys (aliases and Arabic names may have been added)
        t["keys"] = tables.keys_for(t["name"], t.get("short", ""))
    tables.render(tb)
    import matchpages
    archive = matchpages.merge_archive(old.get("match_archive", {}), fx)
    for f in list(archive.values()) + fx:  # spoiler-free excitement score for finished matches
        f["thrill"] = enhance.thrill(f, tb)
    cards = enhance.group_videos(v, list(archive.values()), tb["teams"])
    mark_neutral(cards)
    clusters = enhance.cluster_news(n, tb["teams"])
    slugs, mpages = matchpages.render_all(archive, tb, v, n)
    print(f"{len(n)} news in {len(clusters)} stories, {len(v)} videos in {len(cards)} cards, {len(fx)} fixtures, "
          f"{len(tb['teams'])} teams, {len(mpages)} match pages, {write_sitemap(mpages)} sitemap URLs")
    open("index.html", "w").write(render(clusters, cards, fx, tb["teams"], slugs))
    json.dump(enhance.club_data(tb, archive, fx, cards, clusters, MENA_TV), open("matches/club.json", "w"), ensure_ascii=False, separators=(",", ":"))
    json.dump({"news": [as_json(x) for x in n[:10]],
               "news_all": [as_json(x) for x in n],
               "videos": [as_json(x) for x in v],
               "fixtures": fx, "tables": tb, "match_archive": archive}, open("latest.json", "w"), indent=1)
