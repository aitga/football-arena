/* Football Arena – features shared by every page:
   🙈 Spoiler-Free mode · 🔍 search (press / or Ctrl+K) · club drawer · TV region · saved league filter · "time ago". */
(function () {
"use strict";
var me = document.currentScript, ROOT = me ? me.src.replace(/fa\.js(\?.*)?$/, "") : "";
var LS = {
  get: function (k, d) { try { var v = localStorage.getItem(k); return v == null ? d : v; } catch (e) { return d; } },
  set: function (k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
};
function $(s, r) { return (r || document).querySelector(s); }
function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return {"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"}[c]; }); }
function plain(s) { return String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ًͯ-ٰٟٕٔ]/g, ""); }
var FA = window.FA || {t: function (k) { return k; }, lang: "en", apply: function () {}};
function t(k, v) { return FA.t(k, v); }
function loc() { return FA.lang === "ar" ? "ar-MA" : FA.lang; }

/* ---------------------------------------------------------------- words */
FA.extend && FA.extend({
en: {sf: "Spoiler-Free", reveal: "Tap to reveal score", search: "Search", search_ph: "Search teams, players or leagues…", s_teams: "Teams",
  s_players: "Players", s_leagues: "Leagues", s_none: "No results", s_goals: "{n} goals", s_ast: "{n} assists", s_hint: "Tip: press / to search",
  dr_pos: "Position", dr_pts: "Points", dr_gd: "Goal diff.", dr_p: "Played", dr_form: "Last 5", dr_scorer: "Top scorer", dr_assist: "Top assists",
  dr_next: "Next match", dr_hl: "Latest highlights", dr_news: "Latest news", dr_add: "☆ Add to My Teams", dr_added: "⭐ In My Teams",
  dr_table: "Full table →", tv_region: "TV region", r_auto: "Auto", r_mena: "Arab world & N. Africa", r_uk: "UK", r_usa: "USA", r_all: "All regions",
  d_yest: "Yesterday", d_today: "Today", d_tom: "Tomorrow", next_ko: "Next kick-off in", no_day: "No matches on this day.", hl_btn: "Highlights",
  ft: "FT", yt_off: "↗ Official YouTube", reel: "Play Matchday Reel", reel_t: "Matchday Reel", reel_keys: "N next · P previous · S spoiler-free",
  up_next: "Up next", sort: "Sort:", s_latest: "Latest", s_thrill: "🔥 Most exciting", thr_classic: "Instant Classic", thr_great: "Great Watch",
  guide: "60-sec guide", read_guide: "Read the full guide →", trivia: "Matchday warm-up", trivia_more: "Play the full quiz →", also: "Also on:",
  popup: "This video opens on YouTube – the owner doesn't allow it to play on other sites.", lv_latest: "Latest highlights", lv_days: "Matches this week",
  days_h: "{n} h", days_d: "{n} d", en_only: "in English"},
ar: {sf: "بدون حرق النتائج", reveal: "اضغط لإظهار النتيجة", search: "بحث", search_ph: "ابحث عن فريق أو لاعب أو دوري…", s_teams: "الفرق",
  s_players: "اللاعبون", s_leagues: "الدوريات", s_none: "لا نتائج", s_goals: "{n} أهداف", s_ast: "{n} تمريرات حاسمة", s_hint: "نصيحة: اضغط / للبحث",
  dr_pos: "المركز", dr_pts: "النقاط", dr_gd: "فارق الأهداف", dr_p: "لعب", dr_form: "آخر 5", dr_scorer: "الهداف", dr_assist: "صانع الأهداف",
  dr_next: "المباراة القادمة", dr_hl: "أحدث الملخصات", dr_news: "آخر الأخبار", dr_add: "☆ أضف إلى فرقي", dr_added: "⭐ ضمن فرقي",
  dr_table: "الجدول كاملًا ←", tv_region: "منطقة البث", r_auto: "تلقائي", r_mena: "العالم العربي وشمال أفريقيا", r_uk: "بريطانيا", r_usa: "أمريكا", r_all: "كل المناطق",
  d_yest: "أمس", d_today: "اليوم", d_tom: "غدًا", next_ko: "المباراة القادمة بعد", no_day: "لا توجد مباريات في هذا اليوم.", hl_btn: "الملخص",
  ft: "انتهت", yt_off: "↗ يوتيوب الرسمي", reel: "شغّل كل ملخصات الجولة", reel_t: "ملخصات الجولة", reel_keys: "N التالي · P السابق · S بدون حرق",
  up_next: "التالي", sort: "الترتيب:", s_latest: "الأحدث", s_thrill: "🔥 الأكثر إثارة", thr_classic: "مباراة تاريخية", thr_great: "تستحق المشاهدة",
  guide: "شرح في دقيقة", read_guide: "اقرأ الشرح كاملًا ←", trivia: "سؤال قبل المباريات", trivia_more: "العب الاختبار كاملًا ←", also: "أيضًا في:",
  popup: "يُفتح هذا الفيديو على يوتيوب – مالكه لا يسمح بتشغيله على مواقع أخرى.", lv_latest: "أحدث الملخصات", lv_days: "مباريات هذا الأسبوع",
  days_h: "{n} س", days_d: "{n} ي", en_only: "بالإنجليزية"},
fr: {sf: "Sans spoiler", reveal: "Touchez pour voir le score", search: "Rechercher", search_ph: "Chercher une équipe, un joueur, un championnat…", s_teams: "Équipes",
  s_players: "Joueurs", s_leagues: "Championnats", s_none: "Aucun résultat", s_goals: "{n} buts", s_ast: "{n} passes déc.", s_hint: "Astuce : appuyez sur / pour chercher",
  dr_pos: "Position", dr_pts: "Points", dr_gd: "Diff. de buts", dr_p: "Joués", dr_form: "5 derniers", dr_scorer: "Meilleur buteur", dr_assist: "Meilleur passeur",
  dr_next: "Prochain match", dr_hl: "Derniers résumés", dr_news: "Dernières actus", dr_add: "☆ Ajouter à Mes équipes", dr_added: "⭐ Dans Mes équipes",
  dr_table: "Classement complet →", tv_region: "Région TV", r_auto: "Auto", r_mena: "Monde arabe & Afr. du Nord", r_uk: "Royaume-Uni", r_usa: "États-Unis", r_all: "Toutes",
  d_yest: "Hier", d_today: "Aujourd'hui", d_tom: "Demain", next_ko: "Prochain coup d'envoi dans", no_day: "Aucun match ce jour-là.", hl_btn: "Résumé",
  ft: "Fin", yt_off: "↗ YouTube officiel", reel: "Lancer tous les résumés", reel_t: "Tous les résumés", reel_keys: "N suivant · P précédent · S sans spoiler",
  up_next: "À suivre", sort: "Trier :", s_latest: "Récents", s_thrill: "🔥 Les plus fous", thr_classic: "Match légendaire", thr_great: "À voir",
  guide: "Guide en 60 s", read_guide: "Lire le guide complet →", trivia: "Échauffement du jour", trivia_more: "Jouer au quiz complet →", also: "Aussi sur :",
  popup: "Cette vidéo s'ouvre sur YouTube – son propriétaire n'autorise pas la lecture ailleurs.", lv_latest: "Derniers résumés", lv_days: "Matchs de la semaine",
  days_h: "{n} h", days_d: "{n} j", en_only: "en anglais"},
es: {sf: "Sin spoilers", reveal: "Toca para ver el resultado", search: "Buscar", search_ph: "Busca equipos, jugadores o ligas…", s_teams: "Equipos",
  s_players: "Jugadores", s_leagues: "Ligas", s_none: "Sin resultados", s_goals: "{n} goles", s_ast: "{n} asistencias", s_hint: "Consejo: pulsa / para buscar",
  dr_pos: "Posición", dr_pts: "Puntos", dr_gd: "Dif. de goles", dr_p: "Jugados", dr_form: "Últimos 5", dr_scorer: "Máximo goleador", dr_assist: "Máximo asistente",
  dr_next: "Próximo partido", dr_hl: "Últimos resúmenes", dr_news: "Últimas noticias", dr_add: "☆ Añadir a Mis equipos", dr_added: "⭐ En Mis equipos",
  dr_table: "Tabla completa →", tv_region: "Región de TV", r_auto: "Auto", r_mena: "Mundo árabe y N. de África", r_uk: "Reino Unido", r_usa: "EE. UU.", r_all: "Todas",
  d_yest: "Ayer", d_today: "Hoy", d_tom: "Mañana", next_ko: "Próximo partido en", no_day: "No hay partidos este día.", hl_btn: "Resumen",
  ft: "Final", yt_off: "↗ YouTube oficial", reel: "Ver todos los resúmenes", reel_t: "Resúmenes de la jornada", reel_keys: "N siguiente · P anterior · S sin spoilers",
  up_next: "A continuación", sort: "Ordenar:", s_latest: "Recientes", s_thrill: "🔥 Más emocionantes", thr_classic: "Partidazo", thr_great: "Muy recomendable",
  guide: "Guía en 60 s", read_guide: "Leer la guía completa →", trivia: "Calentamiento", trivia_more: "Jugar el quiz completo →", also: "También en:",
  popup: "Este vídeo se abre en YouTube: su dueño no permite verlo en otras webs.", lv_latest: "Últimos resúmenes", lv_days: "Partidos de la semana",
  days_h: "{n} h", days_d: "{n} d", en_only: "en inglés"},
pt: {sf: "Sem spoiler", reveal: "Toque para ver o placar", search: "Buscar", search_ph: "Busque times, jogadores ou ligas…", s_teams: "Times",
  s_players: "Jogadores", s_leagues: "Ligas", s_none: "Nenhum resultado", s_goals: "{n} gols", s_ast: "{n} assistências", s_hint: "Dica: aperte / para buscar",
  dr_pos: "Posição", dr_pts: "Pontos", dr_gd: "Saldo", dr_p: "Jogos", dr_form: "Últimos 5", dr_scorer: "Artilheiro", dr_assist: "Garçom",
  dr_next: "Próximo jogo", dr_hl: "Últimos vídeos", dr_news: "Últimas notícias", dr_add: "☆ Adicionar aos Meus times", dr_added: "⭐ Nos Meus times",
  dr_table: "Tabela completa →", tv_region: "Região da TV", r_auto: "Auto", r_mena: "Mundo árabe e N. da África", r_uk: "Reino Unido", r_usa: "EUA", r_all: "Todas",
  d_yest: "Ontem", d_today: "Hoje", d_tom: "Amanhã", next_ko: "Próximo jogo em", no_day: "Nenhum jogo neste dia.", hl_btn: "Melhores momentos",
  ft: "Fim", yt_off: "↗ YouTube oficial", reel: "Ver todos os vídeos", reel_t: "Vídeos da rodada", reel_keys: "N próximo · P anterior · S sem spoiler",
  up_next: "A seguir", sort: "Ordenar:", s_latest: "Recentes", s_thrill: "🔥 Mais emocionantes", thr_classic: "Jogaço", thr_great: "Vale a pena",
  guide: "Guia de 60 s", read_guide: "Ler o guia completo →", trivia: "Aquecimento", trivia_more: "Jogar o quiz completo →", also: "Também em:",
  popup: "Este vídeo abre no YouTube – o dono não permite exibi-lo em outros sites.", lv_latest: "Últimos vídeos", lv_days: "Jogos da semana",
  days_h: "{n} h", days_d: "{n} d", en_only: "em inglês"},
de: {sf: "Spoilerfrei", reveal: "Tippen für das Ergebnis", search: "Suchen", search_ph: "Teams, Spieler oder Ligen suchen…", s_teams: "Teams",
  s_players: "Spieler", s_leagues: "Ligen", s_none: "Keine Treffer", s_goals: "{n} Tore", s_ast: "{n} Vorlagen", s_hint: "Tipp: / drücken zum Suchen",
  dr_pos: "Platz", dr_pts: "Punkte", dr_gd: "Tordiff.", dr_p: "Spiele", dr_form: "Letzte 5", dr_scorer: "Torjäger", dr_assist: "Vorlagengeber",
  dr_next: "Nächstes Spiel", dr_hl: "Neueste Highlights", dr_news: "Neueste News", dr_add: "☆ Zu Meinen Teams", dr_added: "⭐ In Meinen Teams",
  dr_table: "Ganze Tabelle →", tv_region: "TV-Region", r_auto: "Auto", r_mena: "Arab. Welt & Nordafrika", r_uk: "Großbritannien", r_usa: "USA", r_all: "Alle",
  d_yest: "Gestern", d_today: "Heute", d_tom: "Morgen", next_ko: "Nächster Anstoß in", no_day: "An diesem Tag keine Spiele.", hl_btn: "Highlights",
  ft: "Ende", yt_off: "↗ Offizielles YouTube", reel: "Alle Highlights abspielen", reel_t: "Spieltag-Highlights", reel_keys: "N weiter · P zurück · S spoilerfrei",
  up_next: "Als Nächstes", sort: "Sortieren:", s_latest: "Neueste", s_thrill: "🔥 Spannendste", thr_classic: "Klassiker", thr_great: "Sehenswert",
  guide: "60-Sek.-Erklärung", read_guide: "Ganze Erklärung lesen →", trivia: "Spieltags-Quiz", trivia_more: "Ganzes Quiz spielen →", also: "Auch bei:",
  popup: "Dieses Video öffnet sich auf YouTube – der Kanal erlaubt kein Abspielen auf anderen Seiten.", lv_latest: "Neueste Highlights", lv_days: "Spiele dieser Woche",
  days_h: "{n} Std.", days_d: "{n} T.", en_only: "auf Englisch"},
it: {sf: "Senza spoiler", reveal: "Tocca per vedere il risultato", search: "Cerca", search_ph: "Cerca squadre, giocatori o campionati…", s_teams: "Squadre",
  s_players: "Giocatori", s_leagues: "Campionati", s_none: "Nessun risultato", s_goals: "{n} gol", s_ast: "{n} assist", s_hint: "Suggerimento: premi / per cercare",
  dr_pos: "Posizione", dr_pts: "Punti", dr_gd: "Diff. reti", dr_p: "Giocate", dr_form: "Ultime 5", dr_scorer: "Capocannoniere", dr_assist: "Miglior assistman",
  dr_next: "Prossima partita", dr_hl: "Ultimi highlights", dr_news: "Ultime notizie", dr_add: "☆ Aggiungi a Le mie squadre", dr_added: "⭐ Nelle mie squadre",
  dr_table: "Classifica completa →", tv_region: "Regione TV", r_auto: "Auto", r_mena: "Mondo arabo e N. Africa", r_uk: "Regno Unito", r_usa: "USA", r_all: "Tutte",
  d_yest: "Ieri", d_today: "Oggi", d_tom: "Domani", next_ko: "Prossimo calcio d'inizio tra", no_day: "Nessuna partita in questo giorno.", hl_btn: "Highlights",
  ft: "Finale", yt_off: "↗ YouTube ufficiale", reel: "Guarda tutti gli highlights", reel_t: "Highlights della giornata", reel_keys: "N avanti · P indietro · S senza spoiler",
  up_next: "Prossimo", sort: "Ordina:", s_latest: "Recenti", s_thrill: "🔥 Più emozionanti", thr_classic: "Partita epica", thr_great: "Da vedere",
  guide: "Guida in 60 s", read_guide: "Leggi la guida completa →", trivia: "Riscaldamento", trivia_more: "Gioca al quiz completo →", also: "Anche su:",
  popup: "Questo video si apre su YouTube: il proprietario non ne consente la visione su altri siti.", lv_latest: "Ultimi highlights", lv_days: "Partite della settimana",
  days_h: "{n} h", days_d: "{n} g", en_only: "in inglese"}
});

var X = window.FAX = {root: ROOT, ls: LS, esc: esc, plain: plain};

/* ---------------------------------------------------------------- time ago (true publish time, in the visitor's language) */
FA.ago = function (ts) {
  var s = Math.round(ts - Date.now() / 1000), a = Math.abs(s);
  try {
    var rtf = new Intl.RelativeTimeFormat(loc(), {numeric: "auto", style: "short"});
    if (a < 3600) return rtf.format(Math.round(s / 60) || -1, "minute");
    if (a < 86400) return rtf.format(Math.round(s / 3600), "hour");
    return rtf.format(Math.round(s / 86400), "day");
  } catch (e) {
    return a < 3600 ? t("ago_m", {n: Math.max(1, Math.round(a / 60))}) : a < 86400 ? t("ago_h", {n: Math.round(a / 3600)}) : t("ago_d", {n: Math.round(a / 86400)});
  }
};
function ticks() { $$(".ago[data-t]").forEach(function (e) { e.textContent = FA.ago(+e.dataset.t); }); }
setInterval(ticks, 60000);

/* ---------------------------------------------------------------- styles */
var css = [
".fa-tools{display:flex;gap:8px;align-items:center;margin-inline-start:auto}",
".fa-tools+.langpick{margin-inline-start:0}",
".fa-btn{display:inline-flex;align-items:center;gap:6px;background:var(--card,#10251a);color:var(--txt,#eef6f0);border:1px solid var(--line,#1f3d2b);border-radius:22px;padding:7px 12px;font:600 14px system-ui,sans-serif;cursor:pointer;white-space:nowrap}",
".fa-btn:hover{border-color:var(--acc,#2ee06f)}.fa-btn[aria-pressed=true]{background:#ffc83d;border-color:#ffc83d;color:#2a1d00}",
".fa-btn kbd{font:600 11px system-ui;border:1px solid var(--line,#1f3d2b);border-radius:5px;padding:0 5px;color:var(--mut,#9cb8a6)}",
"@media(max-width:620px){.fa-btn .lbl,.fa-btn kbd{display:none}}",
/* spoiler-free */
".spoilfree .spoil:not(.rev){font-size:0!important;color:transparent!important;cursor:pointer;display:inline-flex!important;align-items:center;justify-content:center;background:none!important;padding:0!important}",
".spoilfree .spoil:not(.rev)::before{content:var(--fa-rv,'👁');font:700 12px system-ui,sans-serif;color:#ffc83d;background:#1f3d2b;border:1px dashed #ffc83d;border-radius:14px;padding:4px 10px;white-space:nowrap}",
".spoilfree .thumb img{filter:blur(14px) brightness(.5) saturate(.7);transform:scale(1.08)}",
".sfcover{display:none}.spoilfree .sfcover{position:absolute;inset:auto 0 0 0;height:56%;display:flex;align-items:center;justify-content:center;background:linear-gradient(transparent,rgba(0,0,0,.55));gap:10px;padding:0 12px;color:#fff;font-weight:800;font-size:15px;text-align:center;z-index:1;backdrop-filter:blur(2px)}",
".sfcover img{position:static!important;width:44px!important;height:44px!important;object-fit:contain!important;filter:none!important;transform:none!important;background:rgba(255,255,255,.08);border-radius:50%;padding:5px}",
".sfcover i{font-style:normal;color:#9cb8a6;font-size:13px}.sfcover b{max-width:38%;line-height:1.2}",
".spoilfree .thumb .play{z-index:2;opacity:.85;transform:translateY(-34%)}",
".spoilfree .lv-goal{display:none!important}.spoilfree:not(.revall) .tl:not(.rev){filter:blur(7px);cursor:pointer}",
".enb{display:none;font:700 10px system-ui;letter-spacing:.5px;color:#9cb8a6;border:1px solid #1f3d2b;border-radius:5px;padding:1px 5px;vertical-align:1px}html:not([lang=en]) .enb{display:inline-block}",
/* team links */
"[data-team]{cursor:pointer}[data-team]:hover .tn,span[data-team]:hover,td[data-team]:hover{text-decoration:underline;text-decoration-color:var(--acc,#2ee06f);text-underline-offset:3px}",
/* search + drawer */
".fa-ov{position:fixed;inset:0;z-index:80;background:rgba(0,0,0,.62);display:none}.fa-ov.on{display:block}",
".fa-sbox{position:fixed;z-index:81;top:9vh;left:50%;transform:translateX(-50%);width:min(620px,94vw);background:#0d2016;border:1px solid #2a5038;border-radius:16px;box-shadow:0 20px 60px rgba(0,0,0,.6);display:none;overflow:hidden}.fa-sbox.on{display:block}",
".fa-sbox input{width:100%;background:transparent;border:0;border-bottom:1px solid #1f3d2b;color:#eef6f0;font:500 18px system-ui,sans-serif;padding:16px 18px;outline:none}",
".fa-res{max-height:62vh;overflow:auto;padding:6px}.fa-res h4{margin:10px 10px 4px;font:700 12px system-ui;letter-spacing:.6px;text-transform:uppercase;color:#9cb8a6}",
".fa-ri{display:flex;align-items:center;gap:10px;width:100%;text-align:start;background:none;border:0;color:#eef6f0;border-radius:10px;padding:8px 10px;font:600 15px system-ui,sans-serif;cursor:pointer}",
".fa-ri small{color:#9cb8a6;font-weight:500;margin-inline-start:auto;font-size:13px}.fa-ri.sel,.fa-ri:hover{background:#173d25}",
".crest{width:26px;height:26px;object-fit:contain;flex:none}.crest.ini{display:inline-grid;place-items:center;border-radius:50%;background:#1f3d2b;color:#9cb8a6;font:800 11px system-ui}",
".fa-hint{padding:8px 16px 12px;color:#9cb8a6;font-size:12px}",
".fa-dr{position:fixed;z-index:82;top:0;bottom:0;right:0;width:min(420px,100vw);background:#0b1c13;border-inline-start:1px solid #2a5038;transform:translateX(105%);transition:transform .25s ease;overflow:auto;padding:18px 18px 40px;color:#eef6f0;font:15px/1.45 system-ui,sans-serif}",
"[dir=rtl] .fa-dr{right:auto;left:0;transform:translateX(-105%)}.fa-dr.on,[dir=rtl] .fa-dr.on{transform:none}",
".fa-dr .x{position:absolute;top:10px;inset-inline-end:12px;background:none;border:0;color:#eef6f0;font-size:24px;cursor:pointer}",
".dr-h{display:flex;align-items:center;gap:12px;margin:4px 0 14px}.dr-h .crest{width:56px;height:56px}.dr-h b{font-size:21px;line-height:1.2;display:block}.dr-h small{color:#9cb8a6}",
".dr-st{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:14px}.dr-st div{background:#10251a;border:1px solid #1f3d2b;border-radius:12px;padding:8px;text-align:center}",
".dr-st b{display:block;font-size:20px;color:#ffc83d}.dr-st small{color:#9cb8a6;font-size:11px}",
".dr-sec{margin:16px 0 6px;font:700 12px system-ui;letter-spacing:.6px;text-transform:uppercase;color:#9cb8a6}",
".form{display:flex;gap:5px}.form i{width:24px;height:24px;border-radius:50%;display:grid;place-items:center;font:800 11px system-ui;font-style:normal;color:#04210f}",
".form .W{background:#2ee06f}.form .D{background:#9cb8a6}.form .L{background:#ff6b6b}",
".dr-li{display:block;background:#10251a;border:1px solid #1f3d2b;border-radius:10px;padding:8px 10px;margin:6px 0;color:#eef6f0;text-decoration:none;font-size:14px}.dr-li:hover{border-color:#2ee06f}",
".dr-li small{display:block;color:#9cb8a6;font-size:12px}.dr-add{margin-top:16px;width:100%;justify-content:center}",
".spoilfree .dr-li .spoilt{display:none}.dr-li .neu{display:none}.spoilfree .dr-li .neu{display:inline}",
/* ribbon + countdown */
".ribbon{display:flex;gap:6px;overflow-x:auto;scrollbar-width:none;margin:0 0 12px;padding-bottom:2px}",
".rb{flex:none;background:var(--card,#10251a);color:var(--txt,#eef6f0);border:1px solid var(--line,#1f3d2b);border-radius:12px;padding:6px 12px;font:600 13px system-ui,sans-serif;cursor:pointer;text-align:center;line-height:1.25}",
".rb small{display:block;color:var(--mut,#9cb8a6);font-weight:500;font-size:11px}.rb.on{background:var(--acc,#2ee06f);border-color:var(--acc,#2ee06f);color:#04210f}.rb.on small{color:#0b3d1f}.rb:disabled{opacity:.4;cursor:default}",
".cdown{display:flex;flex-wrap:wrap;align-items:center;gap:10px;background:linear-gradient(120deg,#10251a,#14301f);border:1px solid #1f3d2b;border-radius:14px;padding:14px 16px;margin:8px 0 14px}",
".cdown b.n{font:900 26px system-ui;color:#ffc83d;font-variant-numeric:tabular-nums}.cdown small{color:#9cb8a6}",
".tvpick{background:var(--card,#10251a);color:var(--txt,#eef6f0);border:1px solid var(--line,#1f3d2b);border-radius:10px;padding:5px 8px;font:600 13px system-ui,sans-serif}",
".tvr{display:none}.tvr.show{display:block}"
].join("");
var st = document.createElement("style"); st.textContent = css; document.head.appendChild(st);

/* ---------------------------------------------------------------- header buttons */
function header() {
  var lp = $(".langpick"); if (!lp || $(".fa-tools")) return;
  var box = document.createElement("div"); box.className = "fa-tools";
  box.innerHTML = '<button class="fa-btn fa-sbtn" type="button" aria-label="Search">🔍 <span class="lbl" data-i18n="search">Search</span> <kbd>/</kbd></button>' +
    '<button class="fa-btn fa-sf" type="button" aria-pressed="false">🙈 <span class="lbl" data-i18n="sf">Spoiler-Free</span></button>';
  lp.parentNode.insertBefore(box, lp);
  $(".fa-sbtn").onclick = openSearch;
  $(".fa-sf").onclick = function () { setSpoil(!X.spoil); };
}

/* ---------------------------------------------------------------- spoiler-free mode */
X.spoil = LS.get("fa_spoiler_free", "false") === "true";
var realTitle = document.title;
function applySpoil() {
  var on = X.spoil, root = document.documentElement;
  root.classList.toggle("spoilfree", on);
  root.style.setProperty("--fa-rv", JSON.stringify("👁 " + t("reveal")));
  $$(".fa-sf").forEach(function (b) { b.setAttribute("aria-pressed", on ? "true" : "false"); });
  $$("[data-n]").forEach(function (e) {
    if (e.dataset.o == null) e.dataset.o = e.textContent;
    e.textContent = on && e.dataset.n ? e.dataset.n : e.dataset.o;
  });
  document.title = on ? realTitle.replace(/\s\d+\s*[-–]\s*\d+\s/, " vs ").replace(/ – Result & Match Report/, "") : realTitle;
  if (!on) { $$(".rev").forEach(function (e) { e.classList.remove("rev"); }); root.classList.remove("revall"); }
}
function setSpoil(on) {
  X.spoil = !!on; LS.set("fa_spoiler_free", X.spoil ? "true" : "false"); applySpoil();
  document.dispatchEvent(new CustomEvent("fa:spoil", {detail: X.spoil}));
}
X.setSpoil = setSpoil; X.applySpoil = applySpoil;
document.addEventListener("click", function (ev) {
  if (!X.spoil) return;
  var s = ev.target.closest(".spoil:not(.rev), .tl:not(.rev)");
  if (!s) return;
  ev.preventDefault(); ev.stopPropagation();
  s.classList.add("rev");
  if (/live\.html/.test(location.pathname)) document.documentElement.classList.add("revall");
}, true);

/* ---------------------------------------------------------------- saved league filter + My Teams */
X.filter = function () { return LS.get("fa_filter", "all"); };
X.setFilter = function (f) { LS.set("fa_filter", f); document.dispatchEvent(new CustomEvent("fa:filter", {detail: f})); };
X.mine = function () { try { return JSON.parse(LS.get("fa_teams", "[]")); } catch (e) { return []; } };
X.setMine = function (a) { LS.set("fa_teams", JSON.stringify(a)); document.dispatchEvent(new CustomEvent("fa:teams")); };
var dataP = null;
X.data = function () {
  if (!dataP) dataP = fetch(ROOT + "matches/club.json", {cache: "no-cache"}).then(function (r) { return r.json(); }).catch(function () { return {teams: [], players: [], leagues: [], next: [], latest: []}; });
  return dataP;
};
X.mineTest = function () {  // -> Promise(function(text) -> bool)
  return X.data().then(function (d) {
    var keys = [], mine = X.mine();
    d.teams.forEach(function (tm) { if (mine.indexOf(tm.name) >= 0) keys = keys.concat(tm.keys); });
    if (!keys.length) return function () { return false; };
    var rx = new RegExp("(^|[^a-z0-9\\u0600-\\u06ff])(" + keys.map(function (k) { return k.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }).join("|") + ")($|[^a-z0-9\\u0600-\\u06ff])");
    return function (txt) { return rx.test(plain(txt)); };
  });
};
function chipBar() {  // chips on Tables / Matches / Live pages
  var bar = $(".fa-chips"); if (!bar) return;
  function mark() { var f = X.filter(); $$(".chip", bar).forEach(function (c) { c.classList.toggle("on", c.dataset.f === f); }); }
  $$(".chip", bar).forEach(function (c) {
    c.onclick = function () {
      if (c.dataset.f === "my" && !X.mine().length) { location.href = ROOT + "index.html#my"; return; }
      X.setFilter(c.dataset.f); mark();
    };
  });
  mark();
}

/* ---------------------------------------------------------------- TV region */
var MENA = /^(Africa\/(Casablanca|El_Aaiun|Algiers|Tunis|Tripoli|Cairo|Khartoum|Nouakchott)|Asia\/(Riyadh|Dubai|Qatar|Kuwait|Bahrain|Muscat|Amman|Beirut|Baghdad|Damascus|Aden|Gaza|Hebron))$/;
var USA = /^(America\/(New_York|Chicago|Denver|Los_Angeles|Phoenix|Anchorage|Detroit|Boise|Indiana\/.*|Kentucky\/.*|North_Dakota\/.*)|Pacific\/Honolulu)$/;
X.autoRegion = function () {
  var tz = ""; try { tz = Intl.DateTimeFormat().resolvedOptions().timeZone || ""; } catch (e) {}
  return MENA.test(tz) ? "mena" : USA.test(tz) ? "usa" : /^Europe\/(London|Belfast)$/.test(tz) ? "uk" : "all";
};
X.region = function () { var r = LS.get("fa_tv", "auto"); return r === "auto" ? X.autoRegion() : r; };
X.applyTV = function () {
  var r = X.region();
  $$(".mtv").forEach(function (box) {
    var any = false;
    $$(".tvr", box).forEach(function (s) {
      var ok = !s.classList.contains("none") && (r === "all" || s.dataset.r === r);
      s.classList.toggle("show", ok); if (ok) any = true;
    });
    $$(".tvr.none", box).forEach(function (s) { s.classList.toggle("show", !any); });
  });
  $$(".tvpick").forEach(function (s) { s.value = LS.get("fa_tv", "auto"); });
};
function tvPick() {
  $$(".tvpick").forEach(function (s) {
    s.innerHTML = ["auto", "mena", "uk", "usa", "all"].map(function (k) {
      return '<option value="' + k + '">' + (k === "auto" ? "🌍 " + t("r_auto") + " (" + t("r_" + X.autoRegion()) + ")" : t("r_" + k)) + "</option>"; }).join("");
    s.onchange = function () { LS.set("fa_tv", s.value); X.applyTV(); };
  });
  X.applyTV();
}

/* ---------------------------------------------------------------- date ribbon + countdown */
function dayKey(d) { return d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate(); }
X.dayKey = dayKey;
X.ribbon = function (el, stamps, onPick, startDay) {
  var now = new Date(), days = [], counts = {};
  stamps.forEach(function (s) { var k = dayKey(new Date(s * 1000)); counts[k] = (counts[k] || 0) + 1; });
  for (var i = -1; i <= 6; i++) { var d = new Date(now); d.setDate(now.getDate() + i); days.push(d); }
  var lab = function (d, i) {
    if (i === 0) return t("d_yest"); if (i === 1) return t("d_today"); if (i === 2) return t("d_tom");
    try { return d.toLocaleDateString(loc(), {weekday: "short", day: "numeric"}); } catch (e) { return d.getDate(); }
  };
  var pick = startDay;
  if (!pick) { pick = dayKey(now); if (!counts[pick]) { for (var j = 2; j < days.length; j++) if (counts[dayKey(days[j])]) { pick = dayKey(days[j]); break; } } }
  function draw() {
    el.innerHTML = days.map(function (d, i) { var k = dayKey(d), n = counts[k] || 0;
      return '<button class="rb' + (k === pick ? " on" : "") + '" data-k="' + k + '">' + esc(lab(d, i)) + "<small>" + n + " ⚽</small></button>"; }).join("");
    $$(".rb", el).forEach(function (b) { b.onclick = function () { pick = b.dataset.k; draw(); onPick(pick); }; });
  }
  draw(); onPick(pick);
  return {redraw: draw};
};
X.countdown = function (el, ts, label) {
  function fmt(s) {
    var d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60), x = s % 60;
    return (d ? d + "d " : "") + String(h).padStart(2, "0") + ":" + String(m).padStart(2, "0") + ":" + String(x).padStart(2, "0");
  }
  function tick() {
    var s = Math.max(0, Math.round(ts - Date.now() / 1000));
    var n = el.querySelector(".n"); if (n) n.textContent = fmt(s);
  }
  el.innerHTML = "<span>⏱ " + esc(t("next_ko")) + '</span> <b class="n"></b> <small>' + (label || "") + "</small>";
  tick(); clearInterval(el._t); el._t = setInterval(tick, 1000);
};

/* ---------------------------------------------------------------- search */
var ov, sbox, sin, sres, sel = 0, items = [];
function build() {
  if (ov) return;
  ov = document.createElement("div"); ov.className = "fa-ov";
  sbox = document.createElement("div"); sbox.className = "fa-sbox"; sbox.setAttribute("role", "dialog");
  sbox.innerHTML = '<input type="search" autocomplete="off"><div class="fa-res"></div><div class="fa-hint"></div>';
  document.body.appendChild(ov); document.body.appendChild(sbox);
  sin = $("input", sbox); sres = $(".fa-res", sbox);
  ov.onclick = closeAll;
  sin.oninput = function () { sel = 0; draw(); };
  sin.onkeydown = function (e) {
    if (e.key === "ArrowDown") { sel = Math.min(sel + 1, items.length - 1); mark(); e.preventDefault(); }
    else if (e.key === "ArrowUp") { sel = Math.max(sel - 1, 0); mark(); e.preventDefault(); }
    else if (e.key === "Enter" && items[sel]) { items[sel].go(); }
  };
  dr = document.createElement("aside"); dr.className = "fa-dr"; dr.setAttribute("role", "dialog");
  document.body.appendChild(dr);
}
function crest(tm, cls) {
  if (tm && tm.logo) return '<img class="crest ' + (cls || "") + '" src="' + esc(tm.logo) + '" alt="" loading="lazy">';
  var n = tm ? tm.name : "?";
  return '<span class="crest ini ' + (cls || "") + '">' + esc(n.replace(/[^A-Za-z0-9 ]/g, "").split(" ").filter(Boolean).slice(0, 2).map(function (w) { return w[0]; }).join("").toUpperCase() || "⚽") + "</span>";
}
X.crest = crest;
function openSearch() {
  build(); ov.classList.add("on"); sbox.classList.add("on");
  sin.placeholder = t("search_ph"); $(".fa-hint", sbox).textContent = t("s_hint");
  sin.value = ""; sres.innerHTML = '<p class="fa-hint">⏳</p>';
  sin.focus();
  X.data().then(draw);
}
function draw() {
  X.data().then(function (d) {
    var q = plain(sin.value.trim()), res = [];
    var hit = function (s) { return !q || plain(s).indexOf(q) >= 0; };
    var tms = d.teams.filter(function (tm) { return q && (hit(tm.name) || tm.keys.some(function (k) { return k.indexOf(q) === 0; })); }).slice(0, 8);
    if (!q) tms = d.teams.filter(function (tm) { return X.mine().indexOf(tm.name) >= 0; }).slice(0, 8);
    var pls = q ? d.players.filter(function (p) { return hit(p.n); }) : [];
    var seen = {}; pls = pls.filter(function (p) { var k = p.n + p.t; return seen[k] ? false : (seen[k] = 1); }).slice(0, 6);
    var lgs = d.leagues.filter(function (l) { return q ? hit(l.n) : true; }).slice(0, q ? 4 : 7);
    var html = "";
    items = [];
    function row(h, go) { items.push({go: go}); return '<button class="fa-ri" data-i="' + (items.length - 1) + '">' + h + "</button>"; }
    if (tms.length) html += "<h4>" + esc(t("s_teams")) + "</h4>" + tms.map(function (tm) {
      return row(crest(tm) + esc(tm.name) + "<small>" + esc(tm.lg) + " · " + esc(tm.rank) + "º</small>", function () { closeSearch(); openClub(tm.name); }); }).join("");
    if (pls.length) html += "<h4>" + esc(t("s_players")) + "</h4>" + pls.map(function (p) {
      var tm = d.teams.filter(function (x) { return x.name === p.t; })[0];
      return row(crest(tm) + esc(p.n) + "<small>" + esc(p.t) + " · " + esc(t(p.k === "g" ? "s_goals" : "s_ast", {n: p.v})) + "</small>",
        function () { closeSearch(); if (tm) openClub(tm.name); }); }).join("");
    if (lgs.length) html += "<h4>" + esc(t("s_leagues")) + "</h4>" + lgs.map(function (l) {
      return row("🏆 " + esc(l.n), function () { X.setFilter(l.k); location.href = ROOT + "tables.html#" + l.k; }); }).join("");
    sres.innerHTML = html || '<p class="fa-hint">' + esc(t("s_none")) + "</p>";
    $$(".fa-ri", sres).forEach(function (b) { b.onclick = function () { items[+b.dataset.i].go(); }; });
    mark();
  });
}
function mark() { $$(".fa-ri", sres).forEach(function (b, i) { b.classList.toggle("sel", i === sel); if (i === sel) b.scrollIntoView({block: "nearest"}); }); }
function closeSearch() { if (sbox) sbox.classList.remove("on"); if (!dr || !dr.classList.contains("on")) ov && ov.classList.remove("on"); }
function closeAll() { if (sbox) sbox.classList.remove("on"); if (dr) dr.classList.remove("on"); if (ov) ov.classList.remove("on"); }
X.openSearch = openSearch;
document.addEventListener("keydown", function (e) {
  var typing = /input|textarea|select/i.test((e.target.tagName || "")) || e.target.isContentEditable;
  if ((e.key === "k" || e.key === "K") && (e.metaKey || e.ctrlKey)) { e.preventDefault(); openSearch(); }
  else if (e.key === "/" && !typing) { e.preventDefault(); openSearch(); }
  else if (e.key === "Escape") closeAll();
});

/* ---------------------------------------------------------------- club drawer */
var dr;
function when(iso) {
  var d = new Date(iso);
  try { return d.toLocaleDateString(loc(), {weekday: "short", day: "numeric", month: "short"}) + " · " + d.toLocaleTimeString(loc(), {hour: "2-digit", minute: "2-digit"}); } catch (e) { return iso; }
}
function openClub(name) {
  build();
  X.data().then(function (d) {
    var tm = d.teams.filter(function (x) { return x.name === name; })[0];
    if (!tm) { var p = plain(name); tm = d.teams.filter(function (x) { return x.keys.indexOf(p) >= 0; })[0]; }
    if (!tm) return;
    var r = X.region(), nx = tm.next, mine = X.mine().indexOf(tm.name) >= 0;
    var tv = nx ? [(r === "mena" || r === "all") && nx.mena ? "📺 " + t("r_mena") + ": " + nx.mena : "", (r === "usa" || r === "all") && nx.usa ? "📺 " + t("r_usa") + ": " + nx.usa : ""].filter(Boolean).join("<br>") : "";
    var h = '<button class="x" aria-label="Close">✕</button><div class="dr-h">' + crest(tm) + "<div><b>" + esc(tm.name) + "</b><small>" + esc(tm.lg) + "</small></div></div>" +
      '<div class="dr-st"><div><b>' + esc(tm.rank) + "</b><small>" + esc(t("dr_pos")) + "</small></div><div><b>" + esc(tm.pts) + "</b><small>" + esc(t("dr_pts")) +
      "</small></div><div><b>" + esc(tm.gd) + "</b><small>" + esc(t("dr_gd")) + "</small></div><div><b>" + esc(tm.p) + "</b><small>" + esc(t("dr_p")) + "</small></div></div>";
    if (tm.form && tm.form.length) h += '<div class="dr-sec">' + esc(t("dr_form")) + '</div><div class="form spoil">' + tm.form.map(function (f) { return '<i class="' + f + '">' + f + "</i>"; }).join("") + "</div>";
    h += '<div class="dr-sec">' + esc(t("dr_scorer")) + " · " + esc(t("dr_assist")) + "</div><div>⚽ " + (tm.scorer ? esc(tm.scorer.n) + " <b>(" + tm.scorer.v + ")</b>" : "—") +
      "<br>🅰️ " + (tm.assist ? esc(tm.assist.n) + " <b>(" + tm.assist.v + ")</b>" : "—") + "</div>";
    if (nx) h += '<div class="dr-sec">' + esc(t("dr_next")) + '</div><div class="dr-li"><b>' + esc(nx.home) + " vs " + esc(nx.away) + "</b><small>" + esc(when(nx.date)) + " · " + esc(nx.comp) + "</small>" + (tv ? "<small>" + tv + "</small>" : "") + "</div>";
    if (tm.vids.length) h += '<div class="dr-sec">' + esc(t("dr_hl")) + "</div>" + tm.vids.map(function (v) {
      return '<a class="dr-li" href="https://www.youtube.com/watch?v=' + esc(v.id) + '" target="_blank" rel="noopener" data-vid="' + esc(v.id) + '">▶ <span class="spoilt">' + esc(v.t) + '</span><span class="neu">' + esc(v.n || tm.name) + "</span></a>"; }).join("");
    if (tm.news.length) h += '<div class="dr-sec">' + esc(t("dr_news")) + "</div>" + tm.news.map(function (n) {
      return '<a class="dr-li" href="' + esc(n.u) + '" target="_blank" rel="noopener">' + esc(n.t) + " <span class=\"enb\">EN</span><small>" + esc(n.s) + " · " + FA.ago(Date.parse(n.d) / 1000) + "</small></a>"; }).join("");
    h += '<button class="fa-btn dr-add" aria-pressed="' + mine + '">' + esc(t(mine ? "dr_added" : "dr_add")) + "</button>" +
      '<p><a class="dr-li" href="' + ROOT + "tables.html#" + esc(tm.l) + '">' + esc(t("dr_table")) + "</a></p>";
    dr.innerHTML = h; dr.dataset.team = tm.name;
    ov.classList.add("on"); dr.classList.add("on");
    $(".x", dr).onclick = closeAll;
    $(".dr-add", dr).onclick = function () {
      var m = X.mine(), i = m.indexOf(tm.name); if (i >= 0) m.splice(i, 1); else m.push(tm.name); X.setMine(m); openClub(tm.name);
    };
    $$("a[data-vid]", dr).forEach(function (a) { a.addEventListener("click", function (ev) {
      if (window.FAplay) { ev.preventDefault(); closeAll(); window.FAplay(a.dataset.vid); } }); });
  });
}
X.openClub = openClub;
document.addEventListener("click", function (ev) {
  var el = ev.target.closest("[data-team]");
  if (!el || ev.target.closest(".fa-dr")) return;
  if (el.tagName === "TR" && ev.target.closest("a")) return;
  ev.preventDefault(); ev.stopPropagation();
  openClub(el.dataset.team);
});

/* ---------------------------------------------------------------- start */
function start() {
  header(); FA.apply(); applySpoil(); ticks(); chipBar(); tvPick();
  document.addEventListener("fa:lang", function () { applySpoil(); ticks(); tvPick(); });
}
if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();
})();
