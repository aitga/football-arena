"""Football Arena data clean-up and extra features, used by build.py every hour.

- football_only(): drops padel, rugby, NFL, esports... from videos and news
- group_videos():  one card per match; videos of the same match in other commentary
                   languages are merged into that card (EN | IT | ES | AR ...)
- cluster_news():  the same story from BBC, Guardian and ESPN becomes one card with source pills
- thrill():        spoiler-free "how exciting was it" score (0-100) from goals, closeness,
                   late goals, red cards and how high both teams are in the table
- club_data():     data for the search box and the club drawer (club.json)
"""
import datetime
import re
import unicodedata

UTC = datetime.timezone.utc


def plain(s):
    return "".join(ch for ch in unicodedata.normalize("NFD", (s or "").lower()) if unicodedata.category(ch) != "Mn")


# ---------------------------------------------------------------- 1. football only
NOT_FOOTBALL = re.compile(
    r"\bpadel\b|\bfutsal\b|beach soccer|\brugby\b|\bnfl\b|\bnba\b|\bwnba\b|basketball|\btennis\b|\bea ?(sports )?fc\b|"
    r"\besports?\b|\bf1\b|formula (1|one)|\bmotogp\b|\bcricket\b|\bgolf\b|\bboxing\b|\bufc\b|\bmma\b|\bhandball\b|"
    r"\bvolleyball\b|\broblox\b|\bfortnite\b|\befootball\b|\bnhl\b|\bmlb\b|"
    r"البادل|بادل|كرة السلة|السلة|التنس|كرة اليد|الطائرة|فورمولا|الفورمولا|الرياضات الإلكترونية|الملاكمة")


FOOTBALL = re.compile(r"football|soccer|\bfc\b|premier league|la ?liga|serie a|bundesliga|ligue 1|champions league|"
                      r"europa league|world cup|\bcity\b|united|goal|striker|midfielder|defender|goalkeeper|manager|كرة القدم|الدوري")


def football_only(items, key="title", extra=""):
    """Videos come from football channels, but beIN SPORTS also posts padel, basketball... -> drop those.
    News: drop only when the headline is about another sport and nothing in it is about football."""
    out = []
    for it in items:
        title = (it.get(key) or "").lower()
        text = title + " " + ((it.get(extra) or "").lower() if extra else "")
        bad = NOT_FOOTBALL.search(title) if extra else NOT_FOOTBALL.search(text)
        if bad and not (extra and FOOTBALL.search(text)):
            print("Dropped (not football):", it.get(key, "")[:80])
            continue
        out.append(it)
    return out


# ---------------------------------------------------------------- 2. one card per match
LANG_RX = [("ar", r"[؀-ۿ]"), ("it", r"\bsintesi\b|\bgli highlights\b"), ("es", r"\bresumen\b|\bgoles\b"),
           ("fr", r"\brésumé\b|\bresume du match\b"), ("de", r"zusammenfassung|\bspielbericht\b"),
           ("pt", r"melhores momentos")]
AR_CHANNELS = {"beIN SPORTS"}
LANG_ORDER = ["en", "it", "es", "fr", "de", "pt", "ar"]


def lang_of(v):
    if v.get("channel") in AR_CHANNELS:
        return "ar"
    t = (v.get("title") or "").lower()
    for code, rx in LANG_RX:
        if re.search(rx, t):
            return code
    return "en"


def _rank(v):
    t = v["title"].lower()
    return (2 if "extended" in t or "sintesi" in t else 1 if "highlight" in t or "ملخص" in t else 0)


def team_keys(name, teams):
    for t in teams:
        if t["name"] == name:
            return t["keys"]
    p = plain(name)
    return [k for k in {p, p.split(" ")[-1]} if len(k) >= 4]


def _has(text, keys):
    for k in keys:
        if re.search(r"[؀-ۿ]", k):  # Arabic: the word may start with "و" (= and)
            rx = r"(^|[^؀-ۿ])و?" + re.escape(k) + r"($|[^؀-ۿ])"
        else:
            rx = r"(^|[^a-z0-9])" + re.escape(k) + r"($|[^a-z0-9])"
        if re.search(rx, text):
            return True
    return False


HL_RX = re.compile(r"highlight|resumen|sintesi|résumé|zusammenfassung|melhores momentos|ملخص|extended|\| ?md ?\d|matchday", re.I)


def match_fixture(v, fixtures, teams):
    """The finished match a highlight video is about (both team names in the title, uploaded within 4 days).
    Only real match highlights are matched (not referee cams, interviews...)."""
    if not HL_RX.search(v["title"]):
        return None
    text = plain(v["title"])
    best = None
    for f in fixtures:
        if f.get("state") not in ("post", "in"):
            continue
        try:
            ko = datetime.datetime.fromisoformat(f["date"].replace("Z", "+00:00"))
        except Exception:
            continue
        gap = (v["date"] - ko).total_seconds()
        if not (-3 * 3600 < gap < 4 * 86400):
            continue
        if _has(text, team_keys(f["home"], teams)) and _has(text, team_keys(f["away"], teams)):
            if best is None or gap < best[0]:
                best = (gap, f)
    return best[1] if best else None


def _norm_title(t):
    t = plain(t)
    t = re.sub(r"\d+\s*[-–:]\s*\d+", " ", t)
    t = re.sub(r"\b(extended|highlights?|official|matchday|md|round|serie a|enilive|bundesliga|premier league|laliga|ligue 1|"
               r"20\d\d/?\d*|\d+)\b", " ", t)
    return re.sub(r"[^a-z؀-ۿ]+", " ", t).strip()


def group_videos(vids, fixtures, teams):
    """-> list of cards. Each card: dict(video fields of the main version, versions=[...], fixture=f or None)."""
    cards, by_key = [], {}
    for v in sorted(vids, key=lambda x: x["date"], reverse=True):
        v = dict(v, lang=lang_of(v))
        f = match_fixture(v, fixtures, teams)
        key = ("fx", f["id"]) if f else ("t", _norm_title(v["title"]), v["date"].strftime("%Y%m%d"))
        if key not in by_key:
            by_key[key] = {"fixture": f, "versions": []}
            cards.append(by_key[key])
        by_key[key]["versions"].append(v)
    out = []
    for c in cards:
        best = {}
        for v in c["versions"]:  # one video per commentary language: extended highlights first, then newest
            if v["lang"] not in best or _rank(v) > _rank(best[v["lang"]]):
                best[v["lang"]] = v
        versions = sorted(best.values(), key=lambda v: LANG_ORDER.index(v["lang"]) if v["lang"] in LANG_ORDER else 99)
        dropped = len(c["versions"]) - len(versions)
        if dropped:
            print(f"Merged {dropped} duplicate video(s) into: {versions[0]['title'][:70]}")
        main = versions[0]
        out.append(dict(main, versions=versions, fixture=c["fixture"],
                        date=max(v["date"] for v in versions)))
    return sorted(out, key=lambda x: x["date"], reverse=True)


SPOILER_WORDS = re.compile(r"\d+\s*[-–:]\s*\d+|comeback|winner|wins?\b|beat|rescue|draw|brace|hat-?trick|thrash|"
                           r"stun|late|scores?\b|goals?\b|shock|derby-winner|equali[sz]", re.I)


def neutral_title(card, league_name):
    f = card.get("fixture")
    if f:
        return f"{f['home']} vs {f['away']} · {league_name} highlights"
    return f"{card.get('channel') or league_name} video"


# ---------------------------------------------------------------- 3. one card per news story
STOP = set("""the a an and or but of to in on at for from with by as is are was were be been has have had it its this that
these those after before over under into out up down off than then just will would could should can may might not no
says say said new first last more most about against amid why how what who when where which while his her their they he she
we you your our them him all also back one two three four five six seven eight nine ten year years season game games match
football club clubs team teams player players manager boss coach league cup win wins won beat draw lose loses lost goal goals
premier champions europa nations world united city real sport sports bbc espn guardian live report reaction reports""".split())
CAPS_STOP = {"The", "A", "An", "In", "On", "At", "After", "Before", "Why", "How", "What", "Who", "When", "Premier", "League",
             "Champions", "Europa", "Cup", "World", "FA", "England", "Spain", "Italy", "Germany", "France", "Europe",
             "UEFA", "FIFA", "VAR", "BBC", "ESPN", "Guardian", "United", "City", "Real", "Sport", "Football", "Women", "WSL"}


def _tokens(n):
    words = re.findall(r"[a-z][a-z'\-]{3,}", plain(n["title"] + " " + n.get("summary", "")))
    return {w.strip("'-") for w in words if w not in STOP}


def _people(n):
    """Capitalised names in the headline (likely players and managers)."""
    out = set()
    for m in re.finditer(r"(?<![.!?:]\s)(?<!^)\b([A-Z][a-zà-ÿ'\-]{2,})\b", n["title"]):
        w = m.group(1)
        if w not in CAPS_STOP:
            out.add(plain(w))
    return out


def _clubs(n, teams):
    text = plain(n["title"] + " " + n.get("summary", ""))
    return {t["name"] for t in teams if _has(text, [k for k in t["keys"] if len(k) >= 5])}


def cluster_news(items, teams, hours=24):
    """Union-find over stories that overlap: same two clubs, or same named person + similar words."""
    n = len(items)
    info = [(_tokens(it), _people(it), _clubs(it, teams)) for it in items]
    parent = list(range(n))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    for i in range(n):
        for j in range(i + 1, n):
            if abs((items[i]["date"] - items[j]["date"]).total_seconds()) > hours * 3600:
                continue
            ti, pi, ci = info[i]
            tj, pj, cj = info[j]
            jac = len(ti & tj) / max(1, len(ti | tj))
            same = (len(ci & cj) >= 2 and jac >= 0.12) or (pi & pj and jac >= 0.15) or jac >= 0.4
            if same:
                parent[find(i)] = find(j)
    groups = {}
    for i in range(n):
        groups.setdefault(find(i), []).append(items[i])
    out = []
    for g in groups.values():
        g.sort(key=lambda x: x["date"], reverse=True)
        lead = next((x for x in g if x.get("image")), g[0])
        others = [x for x in g if x is not lead]
        if others:
            print(f"Story cluster ({len(g)}): {lead['title'][:70]}")
        out.append(dict(lead, also=others, date=g[0]["date"]))
    return sorted(out, key=lambda x: x["date"], reverse=True)


# ---------------------------------------------------------------- 4. thrill score
def thrill(f, tables):
    """0-100 without spoiling: lots of goals, a close score, late goals, red cards and a big game score higher."""
    try:
        hs, as_ = int(f.get("hs")), int(f.get("as"))
    except (TypeError, ValueError):
        return None
    if f.get("state") != "post":
        return None
    goals, diff = hs + as_, abs(hs - as_)
    ev = f.get("ev") or []
    late = sum(1 for k, m in ev if k == "g" and m >= 80)
    reds = sum(1 for k, _m in ev if k == "r")
    s = min(goals, 5) * 10 + {0: 20, 1: 15, 2: 6}.get(diff, 0) + min(late, 2) * 8 + min(reds, 2) * 6
    ranks = []
    for lg in tables.get("leagues", []):
        for r in lg.get("rows", []):
            if r["team"] in (f["home"], f["away"]) and lg["key"] != "eur":
                try:
                    ranks.append((int(r["rank"]), len(lg["rows"])))
                except ValueError:
                    pass
    if len(ranks) == 2:
        top = sum(1 for rk, n in ranks if rk <= 6)
        s += 10 if top == 2 else 4 if top == 1 else 0
        if abs(ranks[0][0] - ranks[1][0]) <= 2:
            s += 4
    if goals == 0:
        s = min(s, 30)
    return max(0, min(100, s))


def thrill_label(s):
    if s is None:
        return None
    if s >= 85:
        return "classic"
    if s >= 65:
        return "great"
    return None


# ---------------------------------------------------------------- 5. club drawer + search data
def club_data(tables, archive, fixtures, cards, news_cards, mena_tv):
    now = datetime.datetime.now(UTC)
    teams = []
    results = sorted([f for f in archive.values() if f.get("state") == "post"], key=lambda f: f["date"])
    for lg in tables.get("leagues", []):
        for r in lg.get("rows", []):
            if lg["key"] == "eur" and any(t["name"] == r["team"] for t in teams):
                continue
            name = r["team"]
            keys = team_keys(name, tables.get("teams", []))
            form = []
            for f in results:
                if name not in (f["home"], f["away"]):
                    continue
                try:
                    a, b = int(f["hs"]), int(f["as"])
                except (TypeError, ValueError):
                    continue
                mine, theirs = (a, b) if f["home"] == name else (b, a)
                form.append("W" if mine > theirs else "D" if mine == theirs else "L")
            nxt = None
            for f in fixtures:
                if f.get("state") == "pre" and name in (f["home"], f["away"]):
                    ko = datetime.datetime.fromisoformat(f["date"].replace("Z", "+00:00"))
                    if ko > now and (nxt is None or f["date"] < nxt["date"]):
                        nxt = {"date": f["date"], "home": f["home"], "away": f["away"], "comp": f["comp"],
                               "mena": mena_tv.get(f["l"], ""), "usa": ", ".join(f.get("usa", []))}
            scorer = next((p for p in lg.get("scorers", []) if p["team"] == name), None)
            assister = next((p for p in lg.get("assists", []) if p["team"] == name), None)
            vids = [{"id": c["id"], "t": c["title"], "n": c.get("neutral", ""), "d": c["date"].isoformat()}
                    for c in cards if _has(plain(c["title"]), keys)][:3]
            nws = [{"t": n["title"], "u": n["link"], "s": n["source"], "d": n["date"].isoformat()}
                   for n in news_cards if _has(plain(n["title"] + " " + n.get("summary", "")), [k for k in keys if len(k) >= 4])][:3]
            teams.append({"name": name, "l": lg["key"], "lg": lg["name"], "rank": r["rank"], "p": r["p"], "w": r["w"],
                          "d": r["d"], "lo": r["l"], "gd": r["gd"], "pts": r["pts"], "logo": r.get("logo", ""),
                          "keys": keys, "form": form[-5:],
                          "scorer": scorer and {"n": scorer["player"], "v": scorer["value"]},
                          "assist": assister and {"n": assister["player"], "v": assister["value"]},
                          "next": nxt, "vids": vids, "news": nws})
    players = []
    for lg in tables.get("leagues", []):
        for kind, rows in (("g", lg.get("scorers", [])), ("a", lg.get("assists", []))):
            for p in rows:
                players.append({"n": p["player"], "t": p["team"], "k": kind, "v": p["value"], "lg": lg["name"]})
    upcoming = sorted((f for f in fixtures if f.get("state") == "pre"), key=lambda f: f["date"])
    return {"teams": teams, "players": players,
            "leagues": [{"k": lg["key"], "n": lg["name"]} for lg in tables.get("leagues", []) if lg.get("rows")],
            "next": [{"date": f["date"], "home": f["home"], "away": f["away"], "comp": f["comp"], "l": f["l"]} for f in upcoming[:40]],
            "latest": [{"id": c["id"], "t": c["title"], "n": c.get("neutral", ""), "l": c.get("lg", "")} for c in cards[:6]],
            "built": now.isoformat()}


# ---------------------------------------------------------------- 6. tactical guide chips
GUIDES = [("offside-rule-explained", r"\boffside\b", "Offside"),
          ("what-is-var", r"\bvar\b|red card|sent off|penalty review", "VAR"),
          ("football-formations-explained", r"\b4-4-2\b|\b4-3-3\b|\b3-5-2\b|\b4-2-3-1\b|\b3-4-3\b|formation|back three|back five", "Formations")]


def guide_of(text):
    t = (text or "").lower()
    for slug, rx, label in GUIDES:
        if re.search(rx, t):
            return slug, label
    return None
